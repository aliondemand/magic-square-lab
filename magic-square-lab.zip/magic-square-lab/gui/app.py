"""The main window: connects the controls, the grid, the panels and the algorithms.

Layers (see the project README):
    algorithms/ and brute_force/   do the real work, know nothing about windows
    gui/simulation_controller.py   plays events one by one (no tkinter)
    gui/*.py widgets               draw things, never calculate magic squares
    this file                      wires everything together
"""

from __future__ import annotations

import time
import tkinter as tk
from tkinter import messagebox, ttk
from typing import Dict, Optional

from algorithms.dispatcher import MAX_GUI_ORDER, MIN_ORDER, algorithm_info, construct
from algorithms.input_check import InvalidInputError, UnsupportedOrderError, parse_order
from algorithms.simulation_events import Event
from algorithms.validation import magic_constant, validate_square
from brute_force import backtracking_search, naive_search
from brute_force.search_result import BACKTRACKING, FOUND, NAIVE, STRATEGY_NAMES, SearchResult
from brute_force.search_runner import SearchBusyError, SearchRunner, parse_strategy

from .algorithm_panel import AlgorithmPanel
from .controls import ControlsPanel
from .formatting import (delay_for_speed, describe_status, format_seconds,
                         parse_time_limit)
from .grid_view import CURRENT, SELECTED, GridView
from .results_panel import ResultsPanel
from .simulation_controller import (FINISHED, IDLE, PAUSED, READY, RUNNING,
                                    SimulationController)

APP_TITLE = "Magic Square Simulation and Algorithm Analysis"
BACKGROUND = "#f4f6fa"
HEADER_BG = "#1f3a5f"
STATUS_COLORS = {"info": "#1f2933", "ok": "#14733a", "warn": "#9a5b00", "error": "#b42318"}
POLL_MS = 100  # how often the GUI looks for messages from the search thread


class MagicSquareApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.runner = SearchRunner()
        self.confirm = self._ask_confirm        # tests replace this to avoid a real dialog
        self.display_order: Optional[int] = None
        self._searching = False
        self._search_strategy = BACKTRACKING
        self._search_started = 0.0
        self._poll_id: Optional[str] = None
        self._last_count = 0
        self._closing = False

        self._setup_window()
        self._build_ui()

        self.controller = SimulationController(
            root, on_step=self._on_sim_step, on_reset=self._on_sim_reset,
            on_state_change=self._on_sim_state, delay_ms=delay_for_speed(self.controls.speed_level()))
        self.controls.order_var.trace_add("write", self._on_order_text_changed)
        self._on_order_text_changed()
        self._update_buttons()
        self.set_status("Enter an order (3 to 12) and press Construct Magic Square.", "info")

    # =========================================================================
    # Building the window
    # =========================================================================
    def _setup_window(self) -> None:
        root = self.root
        root.title(APP_TITLE)
        root.configure(background=BACKGROUND)
        width = min(1260, root.winfo_screenwidth() - 40)
        height = min(800, root.winfo_screenheight() - 80)
        root.geometry(f"{width}x{height}+20+20")
        root.minsize(980, 640)
        style = ttk.Style(root)
        try:
            style.theme_use("clam")  # gives the same look on every operating system
        except tk.TclError:
            pass
        style.configure(".", background=BACKGROUND, font=("Segoe UI", 10))
        style.configure("TLabelframe", background=BACKGROUND)
        style.configure("TLabelframe.Label", background=BACKGROUND, font=("Segoe UI", 10, "bold"),
                        foreground="#1f3a5f")
        style.configure("TButton", padding=(8, 5))
        style.configure("Accent.TButton", background="#2563eb", foreground="white",
                        font=("Segoe UI", 10, "bold"))
        style.map("Accent.TButton", background=[("disabled", "#b6c3dc"), ("active", "#1d4ed8")],
                  foreground=[("disabled", "#eef2f9")])
        style.configure("Danger.TButton", background="#dc2626", foreground="white")
        style.map("Danger.TButton", background=[("disabled", "#e9c3c3"), ("active", "#b91c1c")],
                  foreground=[("disabled", "#f7eaea")])
        root.protocol("WM_DELETE_WINDOW", self.close)

    def _build_ui(self) -> None:
        root = self.root
        root.columnconfigure(0, weight=1)
        root.rowconfigure(1, weight=1)

        # ---- header ---------------------------------------------------------------
        header = tk.Frame(root, bg=HEADER_BG, padx=16, pady=8)
        header.grid(row=0, column=0, sticky="ew")
        tk.Label(header, text=APP_TITLE, bg=HEADER_BG, fg="white",
                 font=("Segoe UI", 17, "bold")).pack(anchor="w")
        tk.Label(header, bg=HEADER_BG, fg="#cfd9ea", font=("Segoe UI", 10), justify="left",
                 text="Watch odd, doubly-even and singly-even magic squares being built step by step, "
                      "or let brute force search for one, and compare the running times.").pack(anchor="w")
        self.selected_var = tk.StringVar(value="")
        tk.Label(header, textvariable=self.selected_var, bg=HEADER_BG, fg="#ffd166",
                 font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(4, 0))

        # ---- body: controls (full height) | grid + algorithm on top, results below ----
        body = ttk.Frame(root, padding=(10, 8, 10, 6))
        body.grid(row=1, column=0, sticky="nsew")
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)

        self.controls = ControlsPanel(body, {
            "construct": self.on_construct, "start": self.on_start, "pause": self.on_pause,
            "step": self.on_step, "reset": self.on_reset, "stop": self.on_stop,
            "speed": self.on_speed, "mode_changed": self.on_mode_changed,
        })
        self.controls.grid(row=0, column=0, rowspan=2, sticky="ns", padx=(0, 10))

        grid_box = ttk.LabelFrame(body, text="Magic square", padding=6)
        grid_box.grid(row=0, column=1, sticky="nsew")
        self.grid_view = GridView(grid_box)
        self.grid_view.pack(fill="both", expand=True)
        legend = ttk.Frame(grid_box)
        legend.pack(fill="x", pady=(4, 0))
        for text, color in (("empty", "#e8ecf2"), ("filled", "#ffffff"), ("current cell", "#ffc233"),
                            ("swap partner", "#8ec5ff"), ("verified", "#d9f5e0")):
            tk.Label(legend, text="  ", bg=color, relief="solid", borderwidth=1).pack(side="left", padx=(8, 2))
            ttk.Label(legend, text=text).pack(side="left")

        self.algorithm = AlgorithmPanel(body)
        self.algorithm.grid(row=0, column=2, sticky="ns", padx=(10, 0))

        self.results = ResultsPanel(body)
        self.results.grid(row=1, column=1, columnspan=2, sticky="ew", pady=(8, 0))

        # ---- status bar ----------------------------------------------------------------
        self.status_var = tk.StringVar(value="")
        self.status_label = tk.Label(root, textvariable=self.status_var, anchor="w", bg="#e5e9f0",
                                     padx=10, pady=4, font=("Segoe UI", 10))
        self.status_label.grid(row=3, column=0, sticky="ew")

    def set_status(self, text: str, level: str = "info") -> None:
        self.status_var.set(text)
        self.status_label.configure(fg=STATUS_COLORS.get(level, STATUS_COLORS["info"]))

    # =========================================================================
    # Reacting to the order / mode being changed
    # =========================================================================
    def _parse_current_order(self) -> Optional[int]:
        try:
            return parse_order(self.controls.order_var.get())
        except (InvalidInputError, UnsupportedOrderError):
            return None

    def _on_order_text_changed(self, *_args) -> None:
        """Called every time the text in the order box changes."""
        if self._searching or self.controller_running():
            return
        try:
            n = parse_order(self.controls.order_var.get())
        except (InvalidInputError, UnsupportedOrderError) as error:
            self.controls.set_error(str(error), "error")
            self.controls.set_case("")
            return
        self.controls.set_error("", "error")
        if n != self.display_order:
            self.display_order = n
            self._reset_to_idle()
            if getattr(self, "controller", None) is not None:
                self.set_status(f"Order {n} selected. Press Construct Magic Square.", "info")

    def controller_running(self) -> bool:
        controller = getattr(self, "controller", None)
        return controller is not None and controller.state == RUNNING

    def on_mode_changed(self) -> None:
        """The brute-force checkbox or the strategy box was changed."""
        self._reset_to_idle()
        self.set_status("Method changed. Press Construct Magic Square.", "info")

    def _reset_to_idle(self) -> None:
        """Forget any loaded simulation and show an empty grid plus the matching algorithm text."""
        n = self.display_order
        if n is None:
            return
        controller = getattr(self, "controller", None)
        if controller is not None:
            controller.clear(n)
        self.grid_view.set_order(n)
        self.results.clear()
        self._show_algorithm_preview(n)
        self._update_buttons()

    def _show_algorithm_preview(self, n: int) -> None:
        category, name, pseudocode = algorithm_info(n)
        if self.controls.brute_var.get():
            strategy = self._strategy_or_none() or BACKTRACKING
            self.controls.set_case(f"Order {n}: {category}  (brute force selected)")
            self.selected_var.set(f"Selected: n = {n}  |  {category}  |  brute force: {STRATEGY_NAMES[strategy]}")
            self.algorithm.show_algorithm(
                "Brute force: " + STRATEGY_NAMES[strategy],
                "Not constructive: it searches for a square instead of building one.",
                naive_search.PSEUDOCODE if strategy == NAIVE else backtracking_search.PSEUDOCODE)
        else:
            self.controls.set_case(f"Order {n} is {category.upper()}")
            self.selected_var.set(f"Selected: n = {n}  |  {category}  |  {name}")
            self.algorithm.show_algorithm(name, f"Order {n} is {category.lower()}: "
                                          f"n mod 4 = {n % 4}" if n % 2 == 0 else
                                          f"Order {n} is odd", pseudocode)

    def _strategy_or_none(self) -> Optional[str]:
        try:
            return parse_strategy(self.controls.strategy_var.get())
        except ValueError:
            return None

    # =========================================================================
    # Button handlers
    # =========================================================================
    def on_construct(self) -> None:
        if self._searching or self.controller_running():
            return
        try:
            n = parse_order(self.controls.order_var.get())
        except (InvalidInputError, UnsupportedOrderError) as error:
            self.controls.set_error(str(error), "error")
            self.set_status("Please fix the order first.", "error")
            return
        self.controls.set_error("", "error")
        self.display_order = n
        if self.controls.brute_var.get():
            self._start_search(n)
        else:
            self._start_constructive(n)

    def on_start(self) -> None:
        if self.controller.state in (READY, PAUSED):
            self.controller.start()

    def on_pause(self) -> None:
        self.controller.pause()

    def on_step(self) -> None:
        self.controller.step()

    def on_reset(self) -> None:
        self.controller.reset()
        self.set_status("Simulation reset. Press Start or Step.", "info")

    def on_speed(self) -> None:
        level = self.controls.speed_level()
        self.controller.set_delay(delay_for_speed(level))

    def on_stop(self) -> None:
        if self._searching:
            self.runner.cancel()
            self.controls.set_button_states(stop=False)
            self.set_status("Stopping the search...", "warn")

    # =========================================================================
    # Constructive mode
    # =========================================================================
    def _start_constructive(self, n: int) -> None:
        result = construct(n)  # runs instantly; result.elapsed_seconds is the algorithm time only
        self.grid_view.set_order(n)
        self.algorithm.show_algorithm(
            result.algorithm_name,
            f"Order {n} is {result.category.lower()}" +
            (f" (n mod 4 = {n % 4})" if n % 2 == 0 else ""), result.pseudocode)
        self.selected_var.set(f"Selected: n = {n}  |  {result.category}  |  {result.algorithm_name}")
        self.controls.set_case(f"Order {n} is {result.category.upper()}")
        self.results.show_construction(n, result.algorithm_name, magic_constant(n), result.elapsed_seconds)
        self.controller.load(n, result.events)
        self.set_status(f"Ready: {len(result.events)} events. Press Start to watch, or Step to go one event at a time.",
                        "info")

    def _on_sim_reset(self, grid) -> None:
        if self.display_order is None:
            return
        if self.grid_view.n != len(grid):
            self.grid_view.set_order(len(grid))
        self.grid_view.set_valid(False)
        self.grid_view.set_values(grid)
        self.grid_view.clear_highlights()
        self.algorithm.clear_highlight()
        self.algorithm.set_progress(0, self.controller.total, "", "Press Start or Step to begin.")
        self.results.reset_verdict()

    def _on_sim_step(self, index: int, total: int, event: Event, grid) -> None:
        roles: Dict = {}
        for position, (r, c) in enumerate(event.cells):
            self.grid_view.set_cell(r, c, grid[r][c])
            roles[(r, c)] = CURRENT if position == 0 else SELECTED
        self.grid_view.highlight(roles)
        self.algorithm.highlight_line(event.pseudo_line)
        self.algorithm.set_progress(index, total, event.phase, event.message)
        self.set_status(f"Step {index} of {total}", "info")

    def _on_sim_state(self, state: str) -> None:
        self._update_buttons()
        if state == FINISHED:
            self._on_sim_finished()
        elif state == PAUSED:
            self.set_status(f"Paused at step {self.controller.index} of {self.controller.total}.", "info")
        elif state == RUNNING:
            self.set_status("Running...", "info")

    def _on_sim_finished(self) -> None:
        # Verify the grid that is actually on the screen, not a stored copy.
        verdict = validate_square(self.controller.grid)
        self.grid_view.clear_highlights()
        self.grid_view.set_valid(verdict.is_valid)
        self.algorithm.clear_highlight()
        self.results.show_validation(verdict)
        if verdict.is_valid:
            self.set_status(f"Done. Verified: valid magic square of order {verdict.order} "
                            f"(every line sums to {verdict.magic_constant}).", "ok")
        else:
            self.set_status("Done, but the square FAILED verification: " + "; ".join(verdict.errors), "error")

    # =========================================================================
    # Brute-force mode
    # =========================================================================
    def _start_search(self, n: int) -> None:
        try:
            strategy = parse_strategy(self.controls.strategy_var.get())
        except ValueError as error:
            self.controls.set_error(str(error), "error")
            self.set_status("Invalid search strategy.", "error")
            return
        try:
            limit = parse_time_limit(self.controls.time_limit_var.get())
        except ValueError as error:
            self.controls.set_error(str(error), "error")
            self.set_status("Invalid time limit.", "error")
            return
        if strategy == NAIVE:
            warning = naive_search.naive_warning(n)
            if warning and not self.confirm("Naive search is impractical for this order",
                                            warning + "\n\nStart it anyway? It will stop at the limits."):
                self.set_status("Naive search not started.", "warn")
                return

        self._reset_to_idle()
        try:
            self.runner.start(strategy, n, limit)
        except SearchBusyError as error:
            self.set_status(str(error), "error")
            return
        self._searching = True
        self._search_strategy = strategy
        self._search_started = time.perf_counter()
        self._last_count = 0
        self.results.show_search_running(strategy, n, limit)
        self.set_status(f"Searching ({STRATEGY_NAMES[strategy]}, order {n}). The window stays usable; "
                        f"press Stop to cancel.", "info")
        self._update_buttons()
        self._poll_search()

    def _poll_search(self) -> None:
        """Runs on the main thread every 100 ms while a search is active."""
        self._poll_id = None
        if not self._searching or self._closing:
            return
        for message in self.runner.poll():
            if message.kind == "progress":
                self._last_count = message.payload[0]
            elif message.kind == "finished":
                self._on_search_finished(message.payload)
                return
            elif message.kind == "error":
                self._on_search_error(message.payload)
                return
        unit = "arrangements" if self._search_strategy == NAIVE else "nodes"
        self.results.show_search_progress(unit, self._last_count, time.perf_counter() - self._search_started)
        self._poll_id = self.root.after(POLL_MS, self._poll_search)

    def _on_search_finished(self, result: SearchResult) -> None:
        self._searching = False
        self.results.show_search_result(result)
        if result.square is not None:
            self.grid_view.set_order(result.n)
            self.grid_view.set_values(result.square)
            self.grid_view.set_valid(bool(result.validation and result.validation.is_valid))
            self.results.show_validation(result.validation)
            self.algorithm.set_message(result.message)
            if result.status == FOUND and result.validation and result.validation.is_valid:
                self.set_status(f"Search finished: valid magic square found in "
                                f"{format_seconds(result.elapsed_seconds)}.", "ok")
            else:
                self.set_status("The search returned a square that FAILED verification.", "error")
        else:
            self.grid_view.set_order(result.n)
            self.results.show_validation(None, "No square to validate: " + describe_status(result.status))
            self.algorithm.set_message(result.message)
            level = "error" if result.status == "ERROR" else "warn"
            self.set_status(result.message, level)
        self._update_buttons()

    def _on_search_error(self, text: str) -> None:
        self._searching = False
        self.results.vars["s_status"].set("Error")
        self.results.vars["s_note"].set(text)
        self.results.vars["time"].set("-")
        self.results.show_validation(None, "No square to validate: the search failed")
        self.set_status("The search failed: " + text, "error")
        self._update_buttons()

    # =========================================================================
    # Button states: only valid combinations are enabled
    # =========================================================================
    def _update_buttons(self) -> None:
        controls = self.controls
        controller = getattr(self, "controller", None)
        if self._searching:
            controls.set_button_states(construct=False, start=False, pause=False, step=False,
                                       reset=False, stop=True)
            controls.set_start_label("Start")
            controls.lock_inputs(True)
            return
        state = controller.state if controller is not None else IDLE
        playable = state in (READY, PAUSED)
        controls.set_button_states(
            construct=state != RUNNING, start=playable, pause=state == RUNNING, step=playable,
            reset=state != IDLE, stop=False)
        controls.set_start_label("Resume" if state == PAUSED else "Start")
        controls.lock_inputs(state == RUNNING)

    # =========================================================================
    # Misc
    # =========================================================================
    @staticmethod
    def _ask_confirm(title: str, message: str) -> bool:
        return messagebox.askokcancel(title, message, icon="warning")

    def close(self) -> None:
        """Window closed: stop the search thread and every pending timer, then quit."""
        self._closing = True
        self.runner.abandon()
        if self._poll_id is not None:
            try:
                self.root.after_cancel(self._poll_id)
            except tk.TclError:
                pass
        if getattr(self, "controller", None) is not None:
            self.controller.shutdown()
        self.root.destroy()


def run() -> None:
    root = tk.Tk()
    MagicSquareApp(root)
    root.mainloop()
