"""The algorithm explanation panel: name, case, pseudocode and the current step."""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk
from typing import Optional, Sequence

HIGHLIGHT_BG = "#ffe08a"


class AlgorithmPanel(ttk.LabelFrame):
    def __init__(self, master) -> None:
        super().__init__(master, text="Algorithm", padding=8)
        self.name_var = tk.StringVar(value="-")
        self.case_var = tk.StringVar(value="-")
        self.step_var = tk.StringVar(value="Step - / -")
        self.phase_var = tk.StringVar(value="")
        self.message_var = tk.StringVar(value="Choose an order and press Construct Magic Square.")

        ttk.Label(self, textvariable=self.name_var, font=("Segoe UI", 12, "bold"),
                  wraplength=360).pack(anchor="w")
        ttk.Label(self, textvariable=self.case_var, foreground="#4b5563",
                  wraplength=360).pack(anchor="w", pady=(0, 6))

        holder = ttk.Frame(self)
        holder.pack(fill="both", expand=True)
        self.text = tk.Text(holder, height=11, width=46, wrap="word", state="disabled",
                            font=("Consolas", 10), background="#fbfcfe", relief="solid",
                            borderwidth=1, padx=6, pady=6)
        scroll = ttk.Scrollbar(holder, orient="vertical", command=self.text.yview)
        self.text.configure(yscrollcommand=scroll.set)
        self.text.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.text.tag_configure("current", background=HIGHLIGHT_BG)

        ttk.Separator(self).pack(fill="x", pady=8)
        ttk.Label(self, textvariable=self.step_var, font=("Segoe UI", 10, "bold")).pack(anchor="w")
        ttk.Label(self, textvariable=self.phase_var, foreground="#2563eb",
                  wraplength=360).pack(anchor="w")
        self._message = ttk.Label(self, textvariable=self.message_var, wraplength=360, justify="left")
        self._message.pack(anchor="w", pady=(2, 0))
        self.bind("<Configure>", self._rewrap)

    def _rewrap(self, event) -> None:
        width = max(220, event.width - 40)
        self._message.configure(wraplength=width)

    # --- content ---------------------------------------------------------------
    def show_algorithm(self, name: str, case: str, pseudocode: Sequence[str]) -> None:
        self.name_var.set(name)
        self.case_var.set(case)
        self.text.configure(state="normal")
        self.text.delete("1.0", "end")
        self.text.insert("1.0", "\n".join(pseudocode))
        self.text.configure(state="disabled")
        self.clear_highlight()
        self.set_progress(0, 0, "", "")

    def highlight_line(self, index: int) -> None:
        """Highlight pseudocode line number `index` (counting from 0)."""
        self.text.tag_remove("current", "1.0", "end")
        self.text.tag_add("current", f"{index + 1}.0", f"{index + 1}.end")
        self.text.see(f"{index + 1}.0")

    def clear_highlight(self) -> None:
        self.text.tag_remove("current", "1.0", "end")

    def set_progress(self, index: int, total: int, phase: str, message: str) -> None:
        self.step_var.set(f"Step {index} / {total}" if total else "Step - / -")
        self.phase_var.set(phase)
        if message:
            self.message_var.set(message)

    def set_message(self, message: str) -> None:
        self.message_var.set(message)

    def highlighted_line_text(self) -> Optional[str]:
        """The text of the highlighted line, or None (used by the tests)."""
        ranges = self.text.tag_ranges("current")
        if not ranges:
            return None
        return self.text.get(ranges[0], ranges[1])

    def pseudocode_text(self) -> str:
        return self.text.get("1.0", "end").rstrip("\n")
