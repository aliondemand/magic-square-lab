"""Draws the n x n magic square on a Tkinter Canvas.

Each cell is a rectangle with a number on top. The grid is redrawn to fit the
canvas whenever the window is resized, so orders 3 to 12 all stay readable.

Cell appearances (roles):
    empty     light grey   nothing written yet
    filled    white        a number is written
    current   amber        the cell the current event changes
    selected  light blue   the second cell of a swap
    valid     light green  (filled cells once the finished square passed verification)
"""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk
from typing import Dict, List, Tuple

EMPTY, FILLED, CURRENT, SELECTED, VALID = "empty", "filled", "current", "selected", "valid"

FILL_COLORS = {
    EMPTY: "#e8ecf2",
    FILLED: "#ffffff",
    CURRENT: "#ffc233",
    SELECTED: "#8ec5ff",
    VALID: "#d9f5e0",
}
TEXT_COLOR = "#1f2933"
OUTLINE_COLOR = "#8895a7"
BACKGROUND = "#f4f6fa"
MARGIN = 14

Cell = Tuple[int, int]


class GridView(ttk.Frame):
    def __init__(self, master) -> None:
        super().__init__(master)
        self.canvas = tk.Canvas(self, bg=BACKGROUND, highlightthickness=0, width=480, height=480)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<Configure>", lambda event: self._layout())
        self.n = 0
        self._values: List[List[int]] = []
        self._rects: List[List[int]] = []
        self._texts: List[List[int]] = []
        self._roles: Dict[Cell, str] = {}
        self._valid = False

    # --- building ------------------------------------------------------------
    def set_order(self, n: int) -> None:
        """Show an empty n x n grid."""
        self.canvas.delete("all")
        self.n = n
        self._values = [[0] * n for _ in range(n)]
        self._roles = {}
        self._valid = False
        self._rects = [[0] * n for _ in range(n)]
        self._texts = [[0] * n for _ in range(n)]
        for r in range(n):
            for c in range(n):
                self._rects[r][c] = self.canvas.create_rectangle(
                    0, 0, 1, 1, fill=FILL_COLORS[EMPTY], outline=OUTLINE_COLOR, width=1)
                self._texts[r][c] = self.canvas.create_text(
                    0, 0, text="", fill=TEXT_COLOR, font=("Segoe UI", -14, "bold"))
        self._layout()

    def _layout(self) -> None:
        """Position and size every cell so the grid fits the canvas."""
        if self.n == 0:
            return
        width = self.canvas.winfo_width()
        height = self.canvas.winfo_height()
        if width <= 1 or height <= 1:  # window not drawn yet
            width, height = int(self.canvas["width"]), int(self.canvas["height"])
        side = max(min(width, height) - 2 * MARGIN, self.n * 12)
        cell = side / self.n
        x0 = (width - side) / 2
        y0 = (height - side) / 2
        pixels = max(9, min(34, int(cell * 0.42)))
        font = ("Segoe UI", -pixels, "bold")
        for r in range(self.n):
            for c in range(self.n):
                left, top = x0 + c * cell, y0 + r * cell
                self.canvas.coords(self._rects[r][c], left, top, left + cell, top + cell)
                self.canvas.coords(self._texts[r][c], left + cell / 2, top + cell / 2)
                self.canvas.itemconfigure(self._texts[r][c], font=font)

    # --- changing what is shown -----------------------------------------------
    def set_values(self, grid: List[List[int]]) -> None:
        """Show a whole grid (0 = empty cell)."""
        for r in range(self.n):
            for c in range(self.n):
                self._values[r][c] = grid[r][c]
                self._paint(r, c)

    def set_cell(self, r: int, c: int, value: int) -> None:
        self._values[r][c] = value
        self._paint(r, c)

    def highlight(self, roles: Dict[Cell, str]) -> None:
        """Highlight the given cells (cell -> role). Earlier highlights are removed."""
        previous = list(self._roles)
        self._roles = dict(roles)
        for r, c in previous:
            self._paint(r, c)
        for r, c in self._roles:
            self._paint(r, c)

    def clear_highlights(self) -> None:
        self.highlight({})

    def set_valid(self, valid: bool) -> None:
        """Tint the filled cells green when the finished square passed verification."""
        self._valid = valid
        for r in range(self.n):
            for c in range(self.n):
                self._paint(r, c)

    def _paint(self, r: int, c: int) -> None:
        value = self._values[r][c]
        role = self._roles.get((r, c))
        if role is None:
            role = EMPTY if value == 0 else (VALID if self._valid else FILLED)
        self.canvas.itemconfigure(self._rects[r][c], fill=FILL_COLORS[role])
        self.canvas.itemconfigure(self._texts[r][c], text=str(value) if value else "")

    # --- read-only helpers (used by the tests) --------------------------------
    def cell_text(self, r: int, c: int) -> str:
        return self.canvas.itemcget(self._texts[r][c], "text")

    def cell_fill(self, r: int, c: int) -> str:
        return self.canvas.itemcget(self._rects[r][c], "fill")

    def values(self) -> List[List[int]]:
        return [row[:] for row in self._values]
