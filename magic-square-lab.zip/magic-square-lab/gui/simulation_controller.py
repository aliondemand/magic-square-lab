"""Plays a list of events one at a time: Start / Pause / Step / Reset.

This file does NOT import tkinter. It only needs a "scheduler": any object with
    after(milliseconds, function) -> id      and      after_cancel(id)
The Tk root window is such an object. In the tests a fake scheduler is used.

How stale callbacks are prevented
---------------------------------
Every load() and reset() increases a counter called the token. Each scheduled
tick remembers the token it was created with. If the token no longer matches
when the tick runs, the tick does nothing. So a pending tick from an old
simulation can never change a newer one.
"""

from __future__ import annotations

from typing import Callable, List, Optional

from algorithms.simulation_events import Event, apply_event, empty_grid

IDLE = "idle"          # nothing loaded
READY = "ready"        # events loaded, none applied yet
RUNNING = "running"    # the timer is applying events
PAUSED = "paused"      # some events applied, timer stopped
FINISHED = "finished"  # every event applied


class SimulationController:
    def __init__(self, scheduler, on_step: Callable, on_reset: Callable,
                 on_state_change: Callable, delay_ms: int = 150) -> None:
        self._scheduler = scheduler
        self._on_step = on_step                  # (index, total, event, grid)
        self._on_reset = on_reset                # (grid)
        self._on_state_change = on_state_change  # (state)
        self.delay_ms = delay_ms
        self.n = 0
        self.events: List[Event] = []
        self.index = 0                           # how many events have been applied
        self.grid: List[List[int]] = []
        self.state = IDLE
        self._token = 0
        self._timer: Optional[str] = None

    @property
    def total(self) -> int:
        return len(self.events)

    # --- loading / resetting -------------------------------------------------
    def load(self, n: int, events: List[Event]) -> None:
        """Replace the current simulation. Pending ticks of the old one become harmless."""
        self._cancel_timer()
        self._token += 1
        self.n = n
        self.events = list(events)
        self.index = 0
        self.grid = empty_grid(n) if n else []
        self.state = READY if self.events else IDLE
        self._on_state_change(self.state)
        self._on_reset(self._copy_grid())

    def clear(self, n: Optional[int] = None) -> None:
        """Unload the simulation (state becomes IDLE)."""
        self.load(self.n if n is None else n, [])

    def reset(self) -> None:
        """Go back to the start of the loaded simulation."""
        if self.state == IDLE:
            return
        self._cancel_timer()
        self._token += 1
        self.index = 0
        self.grid = empty_grid(self.n)
        self.state = READY
        self._on_state_change(self.state)
        self._on_reset(self._copy_grid())

    # --- playing -------------------------------------------------------------
    def start(self) -> None:
        """Begin or resume. Ignored unless READY or PAUSED (so two timers never exist)."""
        if self.state not in (READY, PAUSED):
            return
        self.state = RUNNING
        self._on_state_change(self.state)
        self._schedule(0)

    def pause(self) -> None:
        if self.state != RUNNING:
            return
        self._cancel_timer()
        self._token += 1
        self.state = PAUSED
        self._on_state_change(self.state)

    def step(self) -> None:
        """Apply exactly ONE event (only when READY or PAUSED)."""
        if self.state not in (READY, PAUSED):
            return
        self._apply_next()
        if self.state != FINISHED:
            self.state = PAUSED
            self._on_state_change(self.state)

    def set_delay(self, delay_ms: int) -> None:
        """Change the pause between events. Takes effect from the next tick."""
        self.delay_ms = max(0, int(delay_ms))

    def shutdown(self) -> None:
        """Cancel any pending tick (used when the window closes)."""
        self._cancel_timer()
        self._token += 1

    # --- internals -----------------------------------------------------------
    def _apply_next(self) -> None:
        event = self.events[self.index]
        apply_event(self.grid, event)
        self.index += 1
        self._on_step(self.index, self.total, event, self._copy_grid())
        if self.index >= self.total:
            self.state = FINISHED
            self._on_state_change(self.state)

    def _schedule(self, delay: int) -> None:
        token = self._token
        self._timer = self._scheduler.after(delay, lambda: self._tick(token))

    def _tick(self, token: int) -> None:
        self._timer = None
        if token != self._token or self.state != RUNNING:
            return  # stale tick from an old run: do nothing
        self._apply_next()
        if self.state == RUNNING:
            self._schedule(self.delay_ms)

    def _cancel_timer(self) -> None:
        if self._timer is not None:
            try:
                self._scheduler.after_cancel(self._timer)
            except Exception:
                pass
            self._timer = None

    def _copy_grid(self) -> List[List[int]]:
        return [row[:] for row in self.grid]
