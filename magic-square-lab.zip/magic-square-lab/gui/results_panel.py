"""The results and verification panel."""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk
from typing import Dict, Optional

from algorithms.validation import ValidationResult
from brute_force.search_result import STRATEGY_NAMES, SearchResult

from .formatting import (describe_status, describe_validation, format_seconds,
                         format_sums, short_note)

GOOD, BAD, NEUTRAL, WARN = "#14733a", "#b42318", "#1f2933", "#9a5b00"


class ResultsPanel(ttk.LabelFrame):
    def __init__(self, master) -> None:
        super().__init__(master, text="Results and verification", padding=8)
        v = {}
        for key in ("order", "algorithm", "magic", "time", "validation", "rows", "cols",
                    "diag", "anti", "s_strategy", "s_examined", "s_pruned", "s_status", "s_note"):
            v[key] = tk.StringVar(value="-")
        self.vars: Dict[str, tk.StringVar] = v

        self.columnconfigure(0, weight=5)
        self.columnconfigure(1, weight=4)
        self.columnconfigure(2, weight=5)

        # --- left block: summary -----------------------------------------------
        left = ttk.Frame(self)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        self._row(left, 0, "Order n:", v["order"])
        self._row(left, 1, "Algorithm used:", v["algorithm"], wrap=170)
        self._row(left, 2, "Magic constant M(n):", v["magic"])
        ttk.Label(left, text="Time taken:").grid(row=3, column=0, sticky="w", pady=2)
        self.time_entry = ttk.Entry(left, textvariable=v["time"], state="readonly", width=14)
        self.time_entry.grid(row=3, column=1, sticky="w", pady=2)
        ttk.Label(left, text="Validation:").grid(row=4, column=0, sticky="nw", pady=2)
        self.validation_label = ttk.Label(left, textvariable=v["validation"], wraplength=110,
                                          font=("Segoe UI", 10, "bold"), justify="left")
        self.validation_label.grid(row=4, column=1, sticky="ew", pady=2)
        self.validation_label.bind(
            "<Configure>", lambda event: self.validation_label.configure(wraplength=max(80, event.width - 2)))
        left.columnconfigure(1, weight=1)

        # --- middle block: sums ---------------------------------------------------
        mid = ttk.Frame(self)
        mid.grid(row=0, column=1, sticky="nsew", padx=10)
        self._row(mid, 0, "Row sums:", v["rows"], wrap=210)
        self._row(mid, 1, "Column sums:", v["cols"], wrap=210)
        self._row(mid, 2, "Main diagonal:", v["diag"])
        self._row(mid, 3, "Secondary diagonal:", v["anti"])

        # --- right block: brute-force search ---------------------------------------
        right = ttk.LabelFrame(self, text="Brute-force search", padding=6)
        right.grid(row=0, column=2, sticky="nsew", padx=(10, 0))
        self._row(right, 0, "Strategy:", v["s_strategy"], wrap=190)
        self._row(right, 1, "Examined:", v["s_examined"], wrap=190)
        self._row(right, 2, "Pruned:", v["s_pruned"], wrap=190)
        self._row(right, 3, "Final status:", v["s_status"], wrap=190)
        self._row(right, 4, "Note:", v["s_note"], wrap=190)
        self.clear()

    @staticmethod
    def _row(parent, row, label, variable, wrap=0):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="nw", pady=1, padx=(0, 6))
        value = ttk.Label(parent, textvariable=variable, wraplength=110, justify="left")
        value.grid(row=row, column=1, sticky="ew", pady=1)
        parent.columnconfigure(1, weight=1)
        # Wrap the text to whatever width the layout gives this label.
        value.bind("<Configure>", lambda event, w=value: w.configure(wraplength=max(80, event.width - 2)))
        return value

    def _set_validation_color(self, color: str) -> None:
        self.validation_label.configure(foreground=color)

    # --- states ----------------------------------------------------------------
    def clear(self) -> None:
        for var in self.vars.values():
            var.set("-")
        self._set_validation_color(NEUTRAL)

    def show_construction(self, n: int, algorithm: str, magic: int, seconds: float) -> None:
        """Called when a constructive run is prepared: everything except the verdict."""
        self.clear()
        self.vars["order"].set(str(n))
        self.vars["algorithm"].set(algorithm)
        self.vars["magic"].set(str(magic))
        self.vars["time"].set(format_seconds(seconds))
        self.vars["validation"].set("Waiting: the simulation has not finished yet")
        self.vars["s_note"].set("Constructive run. Time excludes animation.")

    def reset_verdict(self) -> None:
        """The simulation was reset: the old verdict and sums no longer apply."""
        for key in ("rows", "cols", "diag", "anti"):
            self.vars[key].set("-")
        if self.vars["order"].get() != "-":
            self.vars["validation"].set("Waiting: the simulation has not finished yet")
        self._set_validation_color(NEUTRAL)

    def show_validation(self, result: Optional[ValidationResult], missing_reason: str = "") -> None:
        if result is None:
            for key in ("rows", "cols", "diag", "anti"):
                self.vars[key].set("-")
            self.vars["validation"].set(missing_reason or "No square to validate")
            self._set_validation_color(WARN)
            return
        self.vars["magic"].set(str(result.magic_constant))
        self.vars["rows"].set(format_sums(result.row_sums))
        self.vars["cols"].set(format_sums(result.column_sums))
        self.vars["diag"].set("-" if result.main_diagonal_sum is None else str(result.main_diagonal_sum))
        self.vars["anti"].set("-" if result.secondary_diagonal_sum is None
                              else str(result.secondary_diagonal_sum))
        self.vars["validation"].set(describe_validation(result))
        self._set_validation_color(GOOD if result.is_valid else BAD)

    def show_search_running(self, strategy: str, n: int, time_limit: float) -> None:
        from algorithms.validation import magic_constant
        self.clear()
        self.vars["order"].set(str(n))
        self.vars["algorithm"].set("Brute force: " + STRATEGY_NAMES[strategy])
        self.vars["magic"].set(str(magic_constant(n)))
        self.vars["time"].set("running...")
        self.vars["validation"].set("Waiting for the search to end")
        self.vars["s_strategy"].set(STRATEGY_NAMES[strategy])
        self.vars["s_status"].set("Running")
        self.vars["s_note"].set(f"Limit {time_limit:g} s. Stop cancels.")

    def show_search_progress(self, unit: str, count: int, elapsed: float) -> None:
        self.vars["s_examined"].set(f"{count:,} {unit}")
        self.vars["time"].set(format_seconds(elapsed) + " ...")

    def show_search_result(self, result: SearchResult) -> None:
        self.vars["order"].set(str(result.n))
        self.vars["algorithm"].set("Brute force: " + STRATEGY_NAMES[result.strategy])
        self.vars["time"].set(format_seconds(result.elapsed_seconds))
        self.vars["s_strategy"].set(STRATEGY_NAMES[result.strategy])
        self.vars["s_examined"].set(f"{result.examined:,} {result.unit}")
        self.vars["s_pruned"].set(f"{result.pruned:,}" if result.strategy == "backtracking" else "n/a")
        self.vars["s_status"].set(describe_status(result.status))
        self.vars["s_note"].set(short_note(result))
