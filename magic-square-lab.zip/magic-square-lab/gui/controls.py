"""The left-hand control panel: order input, brute-force options, simulation buttons."""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk
from typing import Callable, Dict

from brute_force.search_result import BACKTRACKING, NAIVE, STRATEGY_NAMES

from .formatting import DEFAULT_SPEED_LEVEL, DEFAULT_TIME_LIMIT_TEXT, delay_for_speed

ERROR_COLOR, OK_COLOR, WARN_COLOR, INFO_COLOR = "#b42318", "#14733a", "#9a5b00", "#4b5563"
LEVEL_COLORS = {"error": ERROR_COLOR, "ok": OK_COLOR, "warn": WARN_COLOR, "info": INFO_COLOR}


class ControlsPanel(ttk.Frame):
    """Holds all inputs and buttons. It does no work itself: it calls the `commands`.

    commands: dict with keys construct, start, pause, step, reset, stop, speed,
              mode_changed
    """

    BUTTONS = ("construct", "start", "pause", "step", "reset", "stop")

    def __init__(self, master, commands: Dict[str, Callable], initial_order: str = "5") -> None:
        super().__init__(master, padding=(0, 0, 0, 0))
        self.order_var = tk.StringVar(value=initial_order)
        self.case_var = tk.StringVar(value="")
        self.error_var = tk.StringVar(value="")
        self.brute_var = tk.BooleanVar(value=False)
        self.strategy_var = tk.StringVar(value=STRATEGY_NAMES[BACKTRACKING])
        self.time_limit_var = tk.StringVar(value=DEFAULT_TIME_LIMIT_TEXT)
        self.speed_var = tk.IntVar(value=DEFAULT_SPEED_LEVEL)
        self.speed_text_var = tk.StringVar(value="")
        self._commands = commands

        # ---- 1. Input -------------------------------------------------------------
        box = ttk.LabelFrame(self, text="1. Input", padding=8)
        box.pack(fill="x")
        ttk.Label(box, text="Order n (3 to 12):").grid(row=0, column=0, sticky="w")
        self.order_entry = ttk.Entry(box, textvariable=self.order_var, width=6, justify="center",
                                     font=("Segoe UI", 12, "bold"))
        self.order_entry.grid(row=0, column=1, sticky="w", padx=(8, 0))
        self.order_entry.bind("<Return>", lambda event: self._commands["construct"]())
        self.case_label = ttk.Label(box, textvariable=self.case_var, foreground="#2563eb",
                                    font=("Segoe UI", 10, "bold"), wraplength=250)
        self.case_label.grid(row=1, column=0, columnspan=2, sticky="w", pady=(6, 0))
        self.error_label = ttk.Label(box, textvariable=self.error_var, foreground=ERROR_COLOR,
                                     wraplength=250, justify="left")
        self.error_label.grid(row=2, column=0, columnspan=2, sticky="w", pady=(4, 0))
        self.error_label.grid_remove()
        self.buttons: Dict[str, ttk.Button] = {}
        self.buttons["construct"] = ttk.Button(box, text="Construct Magic Square", style="Accent.TButton",
                                               command=lambda: self._commands["construct"]())
        self.buttons["construct"].grid(row=3, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        box.columnconfigure(1, weight=1)

        # ---- 2. Method -------------------------------------------------------------
        method = ttk.LabelFrame(self, text="2. Method", padding=8)
        method.pack(fill="x", pady=(8, 0))
        self.brute_check = ttk.Checkbutton(method, text="Solve using brute force",
                                           variable=self.brute_var, command=self._mode_changed)
        self.brute_check.grid(row=0, column=0, columnspan=2, sticky="w")
        ttk.Label(method, text="Strategy:").grid(row=1, column=0, sticky="w", pady=(6, 0))
        self.strategy_box = ttk.Combobox(method, textvariable=self.strategy_var, state="readonly",
                                         values=[STRATEGY_NAMES[NAIVE], STRATEGY_NAMES[BACKTRACKING]],
                                         width=26)
        self.strategy_box.grid(row=2, column=0, columnspan=2, sticky="ew")
        self.strategy_box.bind("<<ComboboxSelected>>", lambda event: self._mode_changed())
        ttk.Label(method, text="Time limit (seconds):").grid(row=3, column=0, sticky="w", pady=(6, 0))
        self.time_entry = ttk.Entry(method, textvariable=self.time_limit_var, width=8)
        self.time_entry.grid(row=3, column=1, sticky="e", pady=(6, 0))
        self.mode_label = ttk.Label(method, text="", foreground=INFO_COLOR, wraplength=250)
        self.mode_label.grid(row=4, column=0, columnspan=2, sticky="w", pady=(6, 0))
        method.columnconfigure(0, weight=1)

        # ---- 3. Simulation ---------------------------------------------------------
        sim = ttk.LabelFrame(self, text="3. Simulation", padding=8)
        sim.pack(fill="x", pady=(8, 0))
        row = ttk.Frame(sim)
        row.pack(fill="x")
        for column, (key, label) in enumerate((("start", "Start"), ("pause", "Pause"), ("step", "Step"))):
            self.buttons[key] = ttk.Button(row, text=label, command=lambda k=key: self._commands[k]())
            self.buttons[key].grid(row=0, column=column, sticky="ew", padx=2)
            row.columnconfigure(column, weight=1)
        row2 = ttk.Frame(sim)
        row2.pack(fill="x", pady=(4, 0))
        self.buttons["reset"] = ttk.Button(row2, text="Reset", command=lambda: self._commands["reset"]())
        self.buttons["reset"].grid(row=0, column=0, sticky="ew", padx=2)
        self.buttons["stop"] = ttk.Button(row2, text="Stop / Cancel search", style="Danger.TButton",
                                          command=lambda: self._commands["stop"]())
        self.buttons["stop"].grid(row=0, column=1, sticky="ew", padx=2)
        row2.columnconfigure(0, weight=1)
        row2.columnconfigure(1, weight=2)

        ttk.Label(sim, text="Speed (slow ... fast):").pack(anchor="w", pady=(10, 0))
        self.speed_scale = ttk.Scale(sim, from_=1, to=10, orient="horizontal")
        self.speed_scale.set(DEFAULT_SPEED_LEVEL)          # set BEFORE attaching the callback,
        self.speed_scale.configure(command=self._speed_moved)  # so it does not fire during start-up
        self.speed_scale.pack(fill="x")
        ttk.Label(sim, textvariable=self.speed_text_var, foreground=INFO_COLOR).pack(anchor="w")
        self._update_speed_text()
        self._apply_brute_widgets()

    # --- speed -------------------------------------------------------------------
    def speed_level(self) -> int:
        return int(round(float(self.speed_scale.get())))

    def _speed_moved(self, _value=None) -> None:
        self.speed_var.set(self.speed_level())
        self._update_speed_text()
        self._commands["speed"]()

    def _update_speed_text(self) -> None:
        level = self.speed_level()
        self.speed_text_var.set(f"Level {level} of 10: {delay_for_speed(level)} ms between events")

    # --- mode (constructive / brute force) -----------------------------------------
    def _mode_changed(self) -> None:
        self._apply_brute_widgets()
        self._commands["mode_changed"]()

    def _apply_brute_widgets(self) -> None:
        on = bool(self.brute_var.get())
        self.strategy_box.configure(state="readonly" if on else "disabled")
        self.time_entry.configure(state="normal" if on else "disabled")
        self.mode_label.configure(
            text=("Mode: BRUTE FORCE (searches for a square, no construction rule)." if on else
                  "Mode: CONSTRUCTIVE (uses the proper algorithm for this order)."))

    # --- called by the app ---------------------------------------------------------
    def set_button_states(self, **enabled: bool) -> None:
        for key, flag in enabled.items():
            self.buttons[key].state(["!disabled"] if flag else ["disabled"])

    def set_start_label(self, text: str) -> None:
        self.buttons["start"].configure(text=text)

    def lock_inputs(self, locked: bool) -> None:
        """Disable the inputs while a simulation is running or a search is in progress."""
        state = "disabled" if locked else "normal"
        self.order_entry.configure(state=state)
        self.brute_check.state(["disabled"] if locked else ["!disabled"])
        if locked:
            self.strategy_box.configure(state="disabled")
            self.time_entry.configure(state="disabled")
        else:
            self._apply_brute_widgets()

    def set_error(self, text: str, level: str = "error") -> None:
        self.error_var.set(text)
        self.error_label.configure(foreground=LEVEL_COLORS.get(level, ERROR_COLOR))
        if text:
            self.error_label.grid()
        else:
            self.error_label.grid_remove()  # no blank gap when there is no message

    def set_case(self, text: str) -> None:
        self.case_var.set(text)
