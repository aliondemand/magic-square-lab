"""Small text/number helpers for the GUI. No tkinter here, so they are easy to test."""

from __future__ import annotations

import math
from typing import Optional, Sequence

from algorithms.validation import ValidationResult
from brute_force import search_result as sr

# Speed levels 1 (slowest) ... 10 (fastest) -> delay between events in milliseconds.
SPEED_DELAYS_MS = [1500, 1000, 700, 500, 350, 250, 150, 80, 30, 5]
DEFAULT_SPEED_LEVEL = 7

MAX_TIME_LIMIT_SECONDS = 3600.0
DEFAULT_TIME_LIMIT_TEXT = "30"


def delay_for_speed(level: int) -> int:
    """Delay in ms for a speed level; out-of-range levels are clamped to 1..10."""
    level = max(1, min(len(SPEED_DELAYS_MS), int(level)))
    return SPEED_DELAYS_MS[level - 1]


def format_seconds(seconds: Optional[float]) -> str:
    """Show a duration as milliseconds (below 1 s) or seconds."""
    if seconds is None:
        return "-"
    if seconds < 1:
        return f"{seconds * 1000:.3f} ms"
    return f"{seconds:.3f} s"


def format_sums(sums: Sequence[int]) -> str:
    return ", ".join(str(s) for s in sums) if sums else "-"


def parse_time_limit(text: str) -> float:
    """Turn the time-limit box into seconds, or raise ValueError with a clear message."""
    text = (text or "").strip()
    if not text:
        raise ValueError("The time limit box is empty. Enter a number of seconds, e.g. 30.")
    try:
        value = float(text)
    except ValueError:
        raise ValueError(f"The time limit '{text}' is not a number. Enter seconds, e.g. 30.") from None
    if not math.isfinite(value) or value <= 0:
        raise ValueError("The time limit must be greater than 0 seconds.")
    if value > MAX_TIME_LIMIT_SECONDS:
        raise ValueError(f"The time limit is too large. Use at most {MAX_TIME_LIMIT_SECONDS:.0f} seconds.")
    return value


STATUS_TEXT = {
    sr.FOUND: "Found a valid magic square",
    sr.EXHAUSTED: "Finished: whole search space explored",
    sr.CANCELLED: "Cancelled by the user (not finished)",
    sr.TIME_LIMIT: "Time limit reached (NOT finished, no square found)",
    sr.COUNT_LIMIT: "Safety limit reached (NOT finished, no square found)",
    sr.ERROR: "Error",
}


def describe_status(status: str) -> str:
    return STATUS_TEXT.get(status, status)


def describe_validation(result: Optional[ValidationResult]) -> str:
    """One line for the validation label."""
    if result is None:
        return "-"
    if result.is_valid:
        return f"VALID magic square (every line sums to {result.magic_constant})"
    return "NOT a magic square: " + "; ".join(result.errors)


def short_note(result) -> str:
    """A one-line note for the small results box (the full text goes to the status bar)."""
    notes = {
        sr.FOUND: "Valid square found.",
        sr.EXHAUSTED: ("Every possibility was tried: no magic square exists."
                       if not result.solution_count else "Search complete."),
        sr.CANCELLED: "Stopped by the user.",
        sr.TIME_LIMIT: "Stopped by the time limit before finishing.",
        sr.COUNT_LIMIT: "Stopped by the safety limit before finishing.",
    }
    return notes.get(result.status, result.message)
