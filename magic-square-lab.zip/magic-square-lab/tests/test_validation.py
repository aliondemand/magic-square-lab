import copy
import unittest

from algorithms import validation
from algorithms.dispatcher import construct
from algorithms.validation import magic_constant, validate_square

GOOD_3 = [[8, 1, 6], [3, 5, 7], [4, 9, 2]]
GOOD_4 = [[16, 2, 3, 13], [5, 11, 10, 8], [9, 7, 6, 12], [4, 14, 15, 1]]


def mutated(square, swaps):
    """Return a copy of the square with the given cell pairs swapped."""
    s = copy.deepcopy(square)
    for (r1, c1), (r2, c2) in swaps:
        s[r1][c1], s[r2][c2] = s[r2][c2], s[r1][c1]
    return s


class TestMagicConstant(unittest.TestCase):
    def test_values_from_the_assignment(self):
        self.assertEqual(magic_constant(3), 15)
        self.assertEqual(magic_constant(4), 34)
        self.assertEqual(magic_constant(5), 65)
        self.assertEqual(magic_constant(6), 111)

    def test_matches_total_divided_by_n_for_all_orders(self):
        for n in range(1, 31):
            self.assertEqual(magic_constant(n) * n, sum(range(1, n * n + 1)))


class TestValidSquares(unittest.TestCase):
    def test_known_good_squares(self):
        for square in (GOOD_3, GOOD_4):
            result = validate_square(square)
            self.assertTrue(result.is_valid, result.summary())
            self.assertEqual(result.errors, [])

    def test_reports_the_actual_sums(self):
        r = validate_square(GOOD_3)
        self.assertEqual(r.order, 3)
        self.assertEqual(r.magic_constant, 15)
        self.assertEqual(r.row_sums, [15, 15, 15])
        self.assertEqual(r.column_sums, [15, 15, 15])
        self.assertEqual(r.main_diagonal_sum, 15)
        self.assertEqual(r.secondary_diagonal_sum, 15)

    def test_every_constructed_order_validates(self):
        for n in range(3, 13):
            r = validate_square(construct(n).square)
            self.assertTrue(r.is_valid)
            self.assertEqual(len(r.row_sums), n)
            self.assertEqual(len(r.column_sums), n)
            self.assertEqual(r.magic_constant, magic_constant(n))

    def test_the_validator_does_not_depend_on_any_algorithm(self):
        with open(validation.__file__, encoding="utf-8") as f:
            source = f.read()
        for name in ("odd_magic_square", "doubly_even", "singly_even", "dispatcher", "simulation_events"):
            self.assertNotIn(name, source)


class TestWrongDimensions(unittest.TestCase):
    def assertInvalid(self, square, fragment):
        result = validate_square(square)
        self.assertFalse(result.is_valid)
        self.assertTrue(any(fragment in e for e in result.errors), result.errors)

    def test_empty_inputs(self):
        self.assertInvalid([], "empty")
        self.assertInvalid(None, "empty")
        self.assertInvalid("abc", "empty")
        self.assertInvalid(7, "empty")

    def test_short_row(self):
        self.assertInvalid([[8, 1, 6], [3, 5], [4, 9, 2]], "wrong length")

    def test_rectangular_grids(self):
        self.assertInvalid([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12]], "not 3 x 3")  # 3 rows, 4 cols
        self.assertInvalid([[1, 2], [3, 4], [5, 6]], "not 3 x 3")                       # 3 rows, 2 cols

    def test_rows_that_are_not_lists(self):
        self.assertInvalid([[8, 1, 6], "357", [4, 9, 2]], "not lists")

    def test_non_integer_cells(self):
        for bad in (5.0, "5", None, True):
            square = copy.deepcopy(GOOD_3)
            square[1][1] = bad
            self.assertInvalid(square, "whole numbers")


class TestValuesAndSums(unittest.TestCase):
    def test_duplicate_value(self):
        square = copy.deepcopy(GOOD_3)
        square[0][0] = 1  # 1 now appears twice, 8 is missing
        r = validate_square(square)
        self.assertFalse(r.is_valid)
        self.assertTrue(any("duplicate values: [1]" in e for e in r.errors))
        self.assertTrue(any("missing values: [8]" in e for e in r.errors))

    def test_missing_value_outside_range(self):
        square = copy.deepcopy(GOOD_3)
        square[2][2] = 10
        r = validate_square(square)
        self.assertFalse(r.is_valid)
        self.assertTrue(any("missing values: [2]" in e for e in r.errors))
        self.assertTrue(any("outside 1..9: [10]" in e for e in r.errors))

    def test_empty_cell_zero_is_not_allowed(self):
        square = copy.deepcopy(GOOD_3)
        square[0][0] = 0
        r = validate_square(square)
        self.assertFalse(r.is_valid)
        self.assertTrue(any("outside" in e for e in r.errors))

    def test_only_rows_wrong(self):
        # Swapping two cells of one column keeps every column sum, and both
        # cells are off the diagonals, so only the two ROW sums break.
        r = validate_square(mutated(GOOD_4, [((1, 0), (2, 0))]))
        self.assertFalse(r.is_valid)
        self.assertTrue(any(e.startswith("row 2") for e in r.errors))
        self.assertTrue(any(e.startswith("row 3") for e in r.errors))
        self.assertFalse(any("column" in e or "diagonal" in e for e in r.errors))
        self.assertEqual(r.row_sums, [34, 38, 30, 34])
        self.assertEqual(r.column_sums, [34, 34, 34, 34])

    def test_only_columns_wrong(self):
        # Swapping two cells of one row keeps every row sum; (0,1) and (0,2)
        # are off both diagonals, so only two COLUMN sums break.
        r = validate_square(mutated(GOOD_4, [((0, 1), (0, 2))]))
        self.assertFalse(r.is_valid)
        self.assertTrue(any(e.startswith("column 2") for e in r.errors))
        self.assertTrue(any(e.startswith("column 3") for e in r.errors))
        self.assertFalse(any(e.startswith("row") or "diagonal" in e for e in r.errors))

    def test_only_diagonals_wrong(self):
        # Swapping two whole rows keeps all row sums and column sums.
        # (Rows 0 and 3 would NOT work for this square: it is symmetric under
        # that swap and stays magic. Rows 0 and 1 really break the diagonals.)
        swaps = [((0, c), (1, c)) for c in range(4)]
        r = validate_square(mutated(GOOD_4, swaps))
        self.assertFalse(r.is_valid)
        self.assertTrue(any("main diagonal" in e for e in r.errors))
        self.assertTrue(any("secondary diagonal" in e for e in r.errors))
        self.assertFalse(any(e.startswith("row") or e.startswith("column") for e in r.errors))
        self.assertEqual(r.row_sums, [34, 34, 34, 34])
        self.assertEqual(r.column_sums, [34, 34, 34, 34])

    def test_sequential_grid_is_not_magic(self):
        n = 4
        grid = [[r * n + c + 1 for c in range(n)] for r in range(n)]
        r = validate_square(grid)
        self.assertFalse(r.is_valid)
        self.assertIn("NOT a magic square", r.summary())


if __name__ == "__main__":
    unittest.main()
