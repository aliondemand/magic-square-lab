import unittest

from algorithms.dispatcher import (DOUBLY_EVEN, ODD, SINGLY_EVEN, classify_order,
                                   construct)
from tests.helpers import MagicSquareTestCase


class TestDispatcher(MagicSquareTestCase):
    def test_classification_for_all_required_orders(self):
        expected = {3: ODD, 4: DOUBLY_EVEN, 5: ODD, 6: SINGLY_EVEN, 7: ODD, 8: DOUBLY_EVEN,
                    9: ODD, 10: SINGLY_EVEN, 11: ODD, 12: DOUBLY_EVEN}
        for n, category in expected.items():
            self.assertEqual(classify_order(n), category)

    def test_every_required_order_constructs_a_valid_square(self):
        for n in range(3, 13):
            with self.subTest(n=n):
                result = construct(n)
                self.assertEqual(result.n, n)
                self.assertEqual(result.category, classify_order(n))
                self.assertGreaterEqual(result.elapsed_seconds, 0)
                self.assertTrue(result.pseudocode)
                self.check_square(result.square, n)

    def test_unsupported_orders_raise(self):
        for n in (-5, 0, 1, 2):
            with self.assertRaises(ValueError):
                classify_order(n)
        for bad in (3.5, "6", None, True):
            with self.assertRaises(ValueError):
                classify_order(bad)


if __name__ == "__main__":
    unittest.main()
