import unittest

from algorithms.simulation_events import PLACE, SWAP
from algorithms.singly_even_magic_square import (PSEUDOCODE,
                                                 singly_even_magic_square,
                                                 singly_even_magic_square_events)
from algorithms.validation import validate_square
from tests.helpers import MagicSquareTestCase


class TestSinglyEvenMagicSquare(MagicSquareTestCase):
    def test_required_orders(self):
        for n in (6, 10):
            with self.subTest(n=n):
                self.check_square(singly_even_magic_square(n), n)

    def test_extra_orders_prove_the_method_is_general(self):
        for n in (14, 18, 22, 26, 30, 34):
            with self.subTest(n=n):
                self.check_square(singly_even_magic_square(n), n)

    def test_order_6_known_result(self):
        self.assertEqual(singly_even_magic_square(6), [
            [35, 1, 6, 26, 19, 24],
            [3, 32, 7, 21, 23, 25],
            [31, 9, 2, 22, 27, 20],
            [8, 28, 33, 17, 10, 15],
            [30, 5, 34, 12, 14, 16],
            [4, 36, 29, 13, 18, 11],
        ])

    def test_events_build_then_swap(self):
        for n in (6, 10, 14):
            events = singly_even_magic_square_events(n)
            places = [e for e in events if e.kind == PLACE]
            swaps = [e for e in events if e.kind == SWAP]
            self.assertEqual(len(places), n * n)
            self.assertEqual(events[: n * n], places)  # swaps only come after all placements
            self.assertGreater(len(swaps), 0)
            m, k = n // 2, (n // 2 - 1) // 2
            self.assertEqual(len(swaps), m * k + m * (k - 1) if k > 0 else 0)
            final = self.check_events(events, n, len(PSEUDOCODE))
            self.assertEqual(final, singly_even_magic_square(n))

    def test_without_the_swaps_the_square_is_NOT_magic(self):
        # Proves the swap step really matters and the validator is not rubber-stamping.
        for n in (6, 10):
            events = [e for e in singly_even_magic_square_events(n) if e.kind == PLACE]
            from algorithms.simulation_events import replay_events
            self.assertFalse(validate_square(replay_events(n, events)).is_valid)

    def test_breaking_the_result_is_detected(self):
        square = singly_even_magic_square(10)
        square[0][0], square[0][1] = square[0][1], square[0][0]
        self.assertFalse(validate_square(square).is_valid)

    def test_invalid_orders_rejected(self):
        for n in (0, 2, 3, 4, 8, 12):
            with self.assertRaises(ValueError):
                singly_even_magic_square_events(n)


if __name__ == "__main__":
    unittest.main()
