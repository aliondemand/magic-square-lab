import time
import unittest
from unittest import mock

from brute_force import search_runner
from brute_force.search_result import CANCELLED, FOUND, NAIVE, TIME_LIMIT
from brute_force.search_runner import (SearchBusyError, SearchRunner, parse_strategy,
                                       run_search)


def collect_until_done(runner, timeout=20.0):
    """Poll like the GUI does; return all messages once the worker has ended."""
    messages = []
    deadline = time.time() + timeout
    while time.time() < deadline:
        messages += runner.poll()
        if not runner.is_running():
            messages += runner.poll()
            return messages
        time.sleep(0.01)
    raise AssertionError("search did not end in time")


class TestParseStrategy(unittest.TestCase):
    def test_valid_choices(self):
        self.assertEqual(parse_strategy("naive"), "naive")
        self.assertEqual(parse_strategy(" Backtracking "), "backtracking")
        self.assertEqual(parse_strategy("Naive permutation search"), "naive")
        self.assertEqual(parse_strategy("Backtracking with pruning"), "backtracking")

    def test_invalid_choices(self):
        for bad in ("", "random", None, 3, "quantum"):
            with self.assertRaises(ValueError):
                parse_strategy(bad)


class TestRunSearch(unittest.TestCase):
    def test_dispatches_to_both_strategies(self):
        self.assertEqual(run_search("naive", 3).strategy, "naive")
        self.assertEqual(run_search("backtracking", 3).strategy, "backtracking")

    def test_naive_has_a_default_safety_limit(self):
        r = run_search("naive", 4, time_limit=0.05)
        self.assertEqual(r.status, TIME_LIMIT)  # stopped by a limit, never ran forever


class TestSearchRunner(unittest.TestCase):
    def test_finishes_and_reports(self):
        runner = SearchRunner()
        run_id = runner.start("backtracking", 4)
        messages = collect_until_done(runner)
        finished = [m for m in messages if m.kind == "finished"]
        self.assertEqual(len(finished), 1)
        self.assertEqual(finished[0].run_id, run_id)
        self.assertEqual(finished[0].payload.status, FOUND)

    def test_cancel(self):
        runner = SearchRunner()
        runner.start("backtracking", 6, time_limit=60)
        time.sleep(0.1)
        self.assertTrue(runner.is_running())
        runner.cancel()
        messages = collect_until_done(runner)
        finished = [m for m in messages if m.kind == "finished"]
        self.assertEqual(finished[0].payload.status, CANCELLED)

    def test_time_limit_and_progress_messages(self):
        runner = SearchRunner()
        runner.start("backtracking", 6, time_limit=0.3)
        messages = collect_until_done(runner)
        self.assertTrue(any(m.kind == "progress" for m in messages))
        finished = [m for m in messages if m.kind == "finished"]
        self.assertEqual(finished[0].payload.status, TIME_LIMIT)

    def test_cannot_start_two_searches_at_once(self):
        runner = SearchRunner()
        runner.start("backtracking", 6, time_limit=60)
        with self.assertRaises(SearchBusyError):
            runner.start("naive", 3)
        runner.cancel()
        collect_until_done(runner)

    def test_stale_results_are_ignored_after_abandon(self):
        runner = SearchRunner()
        old_id = runner.start("backtracking", 6, time_limit=60)
        time.sleep(0.05)
        runner.abandon()                      # like pressing Reset
        self.assertTrue(runner.wait_until_idle(10))
        self.assertEqual(runner.poll(), [])   # nothing from the old run gets through
        new_id = runner.start("backtracking", 3)
        self.assertNotEqual(old_id, new_id)
        messages = collect_until_done(runner)
        finished = [m for m in messages if m.kind == "finished"]
        self.assertEqual(len(finished), 1)
        self.assertEqual(finished[0].run_id, new_id)
        self.assertEqual(finished[0].payload.status, FOUND)

    def test_worker_exception_becomes_an_error_message(self):
        runner = SearchRunner()
        with mock.patch.object(search_runner, "run_search", side_effect=RuntimeError("boom")):
            runner.start("naive", 3)
            messages = collect_until_done(runner)
        errors = [m for m in messages if m.kind == "error"]
        self.assertEqual(len(errors), 1)
        self.assertIn("boom", errors[0].payload)
        self.assertFalse(runner.is_running())

    def test_invalid_strategy_does_not_start_a_thread(self):
        runner = SearchRunner()
        with self.assertRaises(ValueError):
            runner.start("magic", 3)
        self.assertFalse(runner.is_running())

    def test_runner_never_touches_tkinter(self):
        with open(search_runner.__file__, encoding="utf-8") as f:
            code = [line for line in f if line.strip().startswith(("import", "from"))]
        self.assertFalse(any("tkinter" in line for line in code))


if __name__ == "__main__":
    unittest.main()
