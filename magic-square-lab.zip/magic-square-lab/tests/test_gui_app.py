"""Integration tests that drive the REAL Tkinter window.

They create a window, call the same handlers the buttons call, and let Tk's event
loop run. If no display is available (for example a server without a screen) every
test is skipped instead of failing.
"""

import time
import tkinter as tk
import unittest

from algorithms.dispatcher import algorithm_info, construct
from algorithms.validation import magic_constant
from brute_force.search_result import STRATEGY_NAMES
from gui.app import MagicSquareApp
from gui.formatting import delay_for_speed
from gui.simulation_controller import FINISHED, IDLE, PAUSED, READY, RUNNING


class GuiTestCase(unittest.TestCase):
    def setUp(self):
        try:
            self.root = tk.Tk()
        except tk.TclError as error:
            self.skipTest(f"no display available: {error}")
        self.app = MagicSquareApp(self.root)
        self.app.confirm = lambda title, message: True  # never open a real dialog
        self.pump(0.05)

    def tearDown(self):
        try:
            self.app.close()
        except tk.TclError:
            pass
        self.app.runner.wait_until_idle(5)

    # ---- helpers ------------------------------------------------------------
    def pump(self, seconds=0.1):
        end = time.time() + seconds
        while time.time() < end:
            self.root.update()
            time.sleep(0.005)

    def wait_for(self, predicate, timeout=20.0):
        end = time.time() + timeout
        while time.time() < end:
            self.root.update()
            if predicate():
                return True
            time.sleep(0.005)
        return False

    def set_order(self, n):
        self.app.controls.order_var.set(str(n))
        self.pump(0.02)

    def button_enabled(self, name):
        return not self.app.controls.buttons[name].instate(["disabled"])

    def set_brute(self, on, strategy="backtracking", limit="30"):
        if bool(self.app.controls.brute_var.get()) != on:
            self.app.controls.brute_check.invoke()
        self.app.controls.strategy_var.set(STRATEGY_NAMES[strategy])
        self.app.controls._mode_changed()
        self.app.controls.time_limit_var.set(limit)
        self.pump(0.02)

    def filled_cells(self):
        return sum(1 for row in self.app.grid_view.values() for v in row if v)


class TestStartupAndInput(GuiTestCase):
    def test_initial_state(self):
        app = self.app
        self.assertEqual(app.controller.state, IDLE)
        self.assertTrue(self.button_enabled("construct"))
        for name in ("start", "pause", "step", "reset", "stop"):
            self.assertFalse(self.button_enabled(name), name)
        self.assertEqual(app.grid_view.n, 5)
        self.assertEqual(self.filled_cells(), 0)
        self.assertIn("ODD", app.controls.case_var.get())
        self.assertIn("Siamese", app.algorithm.name_var.get())

    def test_case_and_algorithm_for_every_order(self):
        for n in range(3, 13):
            self.set_order(n)
            category, name, pseudocode = algorithm_info(n)
            self.assertIn(category.upper(), self.app.controls.case_var.get(), n)
            self.assertEqual(self.app.algorithm.name_var.get(), name, n)
            self.assertEqual(self.app.algorithm.pseudocode_text(), "\n".join(pseudocode), n)
            self.assertEqual(self.app.grid_view.n, n)

    def test_invalid_inputs_show_a_message_and_do_not_start(self):
        for text, fragment in [("", "empty"), ("abc", "not a number"), ("4.5", "decimal"),
                               ("-3", "negative"), ("0", "zero"), ("1", "trivial"),
                               ("2", "No magic square of order 2"), ("13", "above the supported limit"),
                               ("99999999999", "too large")]:
            with self.subTest(text=text):
                self.app.controls.order_var.set(text)
                self.pump(0.02)
                self.app.on_construct()
                self.assertIn(fragment, self.app.controls.error_var.get())
                self.assertNotEqual(self.app.controller.state, READY)
                self.assertFalse(self.app._searching)

    def test_error_message_disappears_after_a_good_value(self):
        self.app.controls.order_var.set("abc")
        self.pump(0.02)
        self.assertTrue(self.app.controls.error_var.get())
        self.set_order(7)
        self.assertEqual(self.app.controls.error_var.get(), "")


class TestConstructiveSimulation(GuiTestCase):
    def test_step_applies_exactly_one_event(self):
        self.set_order(4)
        self.app.on_construct()
        self.assertEqual(self.app.controller.state, READY)
        self.assertTrue(self.button_enabled("start") and self.button_enabled("step"))
        self.assertFalse(self.button_enabled("pause"))
        self.app.on_step()
        self.assertEqual(self.app.controller.index, 1)
        self.assertEqual(self.filled_cells(), 1)
        self.assertEqual(self.app.algorithm.step_var.get(), "Step 1 / 24")
        self.assertIsNotNone(self.app.algorithm.highlighted_line_text())
        self.app.on_step()
        self.assertEqual(self.filled_cells(), 2)
        self.assertEqual(self.app.controller.state, PAUSED)
        self.assertEqual(self.app.controls.buttons["start"].cget("text"), "Resume")

    def test_current_cell_is_highlighted(self):
        self.set_order(3)
        self.app.on_construct()
        self.app.on_step()
        self.assertEqual(self.app.grid_view.cell_fill(0, 1), "#ffc233")  # 1 goes top row, middle column
        self.assertEqual(self.app.grid_view.cell_text(0, 1), "1")
        self.app.on_step()
        self.assertNotEqual(self.app.grid_view.cell_fill(0, 1), "#ffc233")  # no longer current

    def test_every_order_runs_to_a_verified_square(self):
        self.app.controls.speed_scale.set(10)
        for n in range(3, 13):
            with self.subTest(n=n):
                self.set_order(n)
                self.app.on_construct()
                self.app.controller.set_delay(1)
                self.app.on_start()
                self.assertTrue(self.wait_for(lambda: self.app.controller.state == FINISHED), n)
                expected = construct(n)
                self.assertEqual(self.app.grid_view.values(), expected.square)
                v = self.app.results.vars
                self.assertTrue(v["validation"].get().startswith("VALID"), v["validation"].get())
                self.assertEqual(v["order"].get(), str(n))
                self.assertEqual(v["magic"].get(), str(magic_constant(n)))
                self.assertEqual(v["rows"].get(), ", ".join([str(magic_constant(n))] * n))
                self.assertEqual(v["cols"].get(), ", ".join([str(magic_constant(n))] * n))
                self.assertEqual(v["diag"].get(), str(magic_constant(n)))
                self.assertEqual(v["anti"].get(), str(magic_constant(n)))
                self.assertNotEqual(v["time"].get(), "-")
                self.assertEqual(self.app.grid_view.cell_fill(0, 0), "#d9f5e0")  # verified tint
                self.assertTrue(self.button_enabled("reset"))
                self.assertFalse(self.button_enabled("start"))

    def test_pause_and_resume(self):
        self.set_order(7)
        self.app.on_construct()
        self.app.controller.set_delay(10)
        self.app.on_start()
        self.assertEqual(self.app.controller.state, RUNNING)
        self.assertFalse(self.button_enabled("start"))
        self.assertTrue(self.button_enabled("pause"))
        self.assertFalse(self.button_enabled("construct"))     # no second simulation while running
        self.assertTrue(self.wait_for(lambda: self.app.controller.index >= 5))
        self.app.on_pause()
        frozen = self.app.controller.index
        self.pump(0.3)
        self.assertEqual(self.app.controller.index, frozen)    # really paused
        self.assertEqual(self.app.controller.state, PAUSED)
        self.assertEqual(self.app.controls.buttons["start"].cget("text"), "Resume")
        self.app.on_start()
        self.assertTrue(self.wait_for(lambda: self.app.controller.state == FINISHED))
        self.assertEqual(self.app.grid_view.values(), construct(7).square)

    def test_inputs_are_locked_while_running(self):
        self.set_order(7)
        self.app.on_construct()
        self.app.controller.set_delay(50)
        self.app.on_start()
        self.assertTrue(self.app.controls.order_entry.instate(["disabled"]))
        self.app.on_pause()
        self.assertFalse(self.app.controls.order_entry.instate(["disabled"]))

    def test_reset_clears_everything(self):
        self.set_order(5)
        self.app.on_construct()
        for _ in range(7):
            self.app.on_step()
        self.assertEqual(self.filled_cells(), 7)
        self.app.on_reset()
        self.assertEqual(self.filled_cells(), 0)
        self.assertEqual(self.app.controller.state, READY)
        self.assertEqual(self.app.algorithm.step_var.get(), "Step 0 / 25")
        self.assertIsNone(self.app.algorithm.highlighted_line_text())
        self.assertIn("Waiting", self.app.results.vars["validation"].get())
        self.app.on_step()                                      # can be played again
        self.assertEqual(self.filled_cells(), 1)

    def test_reset_while_running_leaves_no_stale_updates(self):
        self.set_order(9)
        self.app.on_construct()
        self.app.controller.set_delay(20)
        self.app.on_start()
        self.assertTrue(self.wait_for(lambda: self.app.controller.index >= 3))
        self.app.on_reset()
        self.pump(0.4)                                          # any stale timer would fire now
        self.assertEqual(self.app.controller.index, 0)
        self.assertEqual(self.filled_cells(), 0)
        self.assertEqual(self.app.controller.state, READY)

    def test_reset_after_finish_allows_replay(self):
        self.set_order(3)
        self.app.on_construct()
        self.app.controller.set_delay(1)
        self.app.on_start()
        self.assertTrue(self.wait_for(lambda: self.app.controller.state == FINISHED))
        self.app.on_reset()
        self.assertEqual(self.filled_cells(), 0)
        self.assertNotEqual(self.app.grid_view.cell_fill(0, 0), "#d9f5e0")
        self.app.on_start()
        self.assertTrue(self.wait_for(lambda: self.app.controller.state == FINISHED))
        self.assertEqual(self.app.grid_view.values(), construct(3).square)

    def test_swap_events_highlight_two_cells(self):
        self.set_order(6)
        self.app.on_construct()
        while self.app.controller.index < 37:                   # 36 placements, then swaps
            self.app.on_step()
        self.assertEqual(self.app.controller.events[36].kind, "SWAP")
        fills = {self.app.grid_view.cell_fill(r, c) for r in range(6) for c in range(6)}
        self.assertIn("#ffc233", fills)
        self.assertIn("#8ec5ff", fills)

    def test_speed_slider_changes_the_delay(self):
        self.app.controls.speed_scale.set(1)
        self.app.controls._speed_moved()
        self.assertEqual(self.app.controller.delay_ms, delay_for_speed(1))
        self.app.controls.speed_scale.set(10)
        self.app.controls._speed_moved()
        self.assertEqual(self.app.controller.delay_ms, delay_for_speed(10))
        self.assertIn("5 ms", self.app.controls.speed_text_var.get())

    def test_changing_the_order_after_a_run_resets_the_view(self):
        self.set_order(3)
        self.app.on_construct()
        self.app.controller.set_delay(1)
        self.app.on_start()
        self.assertTrue(self.wait_for(lambda: self.app.controller.state == FINISHED))
        self.set_order(6)
        self.assertEqual(self.app.controller.state, IDLE)
        self.assertEqual(self.app.grid_view.n, 6)
        self.assertEqual(self.filled_cells(), 0)
        self.assertEqual(self.app.algorithm.name_var.get(), "Strachey's method")
        self.assertEqual(self.app.results.vars["validation"].get(), "-")
        self.assertFalse(self.button_enabled("start"))
        self.assertTrue(self.button_enabled("construct"))

    def test_construct_again_while_paused_replaces_the_simulation(self):
        self.set_order(5)
        self.app.on_construct()
        for _ in range(4):
            self.app.on_step()
        self.app.on_construct()                                  # same order, fresh run
        self.assertEqual(self.app.controller.index, 0)
        self.assertEqual(self.filled_cells(), 0)
        self.assertEqual(self.app.controller.state, READY)


class TestBruteForceInGui(GuiTestCase):
    def test_backtracking_order_4_found_and_verified(self):
        self.set_order(4)
        self.set_brute(True, "backtracking")
        self.app.on_construct()
        self.assertTrue(self.app._searching)
        self.assertTrue(self.wait_for(lambda: not self.app._searching))
        v = self.app.results.vars
        self.assertEqual(self.filled_cells(), 16)
        self.assertTrue(v["validation"].get().startswith("VALID"))
        self.assertIn("nodes", v["s_examined"].get())
        self.assertEqual(v["s_status"].get(), "Found a valid magic square")
        self.assertNotEqual(v["time"].get(), "-")
        self.assertIn("Backtracking", v["algorithm"].get())

    def test_naive_order_3_found_and_verified(self):
        self.set_order(3)
        self.set_brute(True, "naive")
        self.app.on_construct()
        self.assertTrue(self.wait_for(lambda: not self.app._searching))
        v = self.app.results.vars
        self.assertTrue(v["validation"].get().startswith("VALID"))
        self.assertIn("arrangements", v["s_examined"].get())
        self.assertEqual(v["s_pruned"].get(), "n/a")

    def test_naive_order_4_can_be_declined(self):
        self.set_order(4)
        self.set_brute(True, "naive")
        asked = []
        self.app.confirm = lambda title, message: asked.append(message) or False
        self.app.on_construct()
        self.assertEqual(len(asked), 1)
        self.assertIn("20,922,789,888,000", asked[0])
        self.assertFalse(self.app._searching)
        self.assertIn("not started", self.app.status_var.get())

    def test_naive_order_4_stops_at_a_limit_and_is_not_reported_as_success(self):
        self.set_order(4)
        self.set_brute(True, "naive", limit="0.3")
        self.app.on_construct()
        self.assertTrue(self.wait_for(lambda: not self.app._searching))
        v = self.app.results.vars
        self.assertIn("NOT finished", v["s_status"].get())
        self.assertIn("No square to validate", v["validation"].get())
        self.assertEqual(self.filled_cells(), 0)
        self.assertNotIn("VALID", v["validation"].get().replace("No square to validate", ""))

    def test_backtracking_time_limit_reported_honestly(self):
        self.set_order(6)
        self.set_brute(True, "backtracking", limit="0.3")
        self.app.on_construct()
        self.assertTrue(self.wait_for(lambda: not self.app._searching))
        v = self.app.results.vars
        self.assertIn("Time limit reached", v["s_status"].get())
        self.assertIn("No square to validate", v["validation"].get())
        self.assertEqual(self.filled_cells(), 0)
        self.assertNotEqual(v["time"].get(), "-")

    def test_stop_cancels_a_search(self):
        self.set_order(6)
        self.set_brute(True, "backtracking", limit="60")
        self.app.on_construct()
        self.pump(0.3)
        self.assertTrue(self.app._searching)
        self.assertTrue(self.button_enabled("stop"))
        self.assertFalse(self.button_enabled("construct"))
        self.assertTrue(self.app.controls.order_entry.instate(["disabled"]))
        self.app.on_stop()
        self.assertTrue(self.wait_for(lambda: not self.app._searching, 10))
        v = self.app.results.vars
        self.assertIn("Cancelled", v["s_status"].get())
        self.assertIn("No square to validate", v["validation"].get())
        self.assertTrue(self.button_enabled("construct"))
        self.assertFalse(self.button_enabled("stop"))
        self.assertFalse(self.app.controls.order_entry.instate(["disabled"]))

    def test_gui_stays_responsive_during_a_search(self):
        self.set_order(6)
        self.set_brute(True, "backtracking", limit="60")
        ticks = []
        state = {"id": None}

        def heartbeat():
            ticks.append(time.perf_counter())
            state["id"] = self.root.after(10, heartbeat)

        state["id"] = self.root.after(10, heartbeat)
        self.app.on_construct()
        self.pump(1.0)
        self.root.after_cancel(state["id"])
        self.assertTrue(self.app._searching)
        self.assertGreater(len(ticks), 25, "the window froze while the search was running")
        gaps = [b - a for a, b in zip(ticks, ticks[1:])]
        self.assertLess(max(gaps), 0.5)
        self.app.on_stop()
        self.assertTrue(self.wait_for(lambda: not self.app._searching, 10))

    def test_progress_is_shown_while_searching(self):
        self.set_order(6)
        self.set_brute(True, "backtracking", limit="60")
        self.app.on_construct()
        self.assertTrue(self.wait_for(lambda: "nodes" in self.app.results.vars["s_examined"].get(), 5))
        self.assertEqual(self.app.results.vars["s_status"].get(), "Running")
        self.app.on_stop()
        self.assertTrue(self.wait_for(lambda: not self.app._searching, 10))

    def test_cannot_start_a_second_search_while_one_runs(self):
        self.set_order(6)
        self.set_brute(True, "backtracking", limit="60")
        self.app.on_construct()
        run_id = self.app.runner.run_id
        self.app.on_construct()
        self.assertEqual(self.app.runner.run_id, run_id)
        self.app.on_stop()
        self.assertTrue(self.wait_for(lambda: not self.app._searching, 10))

    def test_invalid_time_limit_and_strategy_are_reported(self):
        self.set_order(4)
        self.set_brute(True, "backtracking", limit="abc")
        self.app.on_construct()
        self.assertIn("not a number", self.app.controls.error_var.get())
        self.assertFalse(self.app._searching)
        self.app.controls.time_limit_var.set("0")
        self.app.on_construct()
        self.assertIn("greater than 0", self.app.controls.error_var.get())
        self.app.controls.time_limit_var.set("5")
        self.app.controls.strategy_var.set("quantum search")
        self.app.on_construct()
        self.assertIn("Unknown search strategy", self.app.controls.error_var.get())
        self.assertFalse(self.app._searching)

    def test_switching_between_modes_resets_the_view_and_text(self):
        self.set_order(4)
        self.assertEqual(self.app.algorithm.name_var.get(), "Diagonal / complement method")
        self.set_brute(True, "naive")
        self.assertIn("Naive", self.app.algorithm.name_var.get())
        self.set_brute(True, "backtracking")
        self.assertIn("Backtracking", self.app.algorithm.name_var.get())
        self.set_brute(False)
        self.assertEqual(self.app.algorithm.name_var.get(), "Diagonal / complement method")

    def test_constructive_after_search_works(self):
        self.set_order(3)
        self.set_brute(True, "backtracking")
        self.app.on_construct()
        self.assertTrue(self.wait_for(lambda: not self.app._searching))
        self.set_brute(False)
        self.app.on_construct()
        self.app.controller.set_delay(1)
        self.app.on_start()
        self.assertTrue(self.wait_for(lambda: self.app.controller.state == FINISHED))
        self.assertEqual(self.app.grid_view.values(), construct(3).square)
        self.assertIn("Siamese", self.app.results.vars["algorithm"].get())

    def test_closing_the_window_stops_the_search_thread(self):
        self.set_order(6)
        self.set_brute(True, "backtracking", limit="60")
        self.app.on_construct()
        self.pump(0.2)
        self.assertTrue(self.app.runner.is_running())
        self.app.close()
        self.assertTrue(self.app.runner.wait_until_idle(10))


if __name__ == "__main__":
    unittest.main()
