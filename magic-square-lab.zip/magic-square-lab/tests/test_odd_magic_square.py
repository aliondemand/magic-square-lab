import unittest

from algorithms.odd_magic_square import (PSEUDOCODE, odd_magic_square,
                                         odd_magic_square_events)
from tests.helpers import MagicSquareTestCase


class TestOddMagicSquare(MagicSquareTestCase):
    def test_required_orders(self):
        for n in (3, 5, 7, 9, 11):
            with self.subTest(n=n):
                self.check_square(odd_magic_square(n), n)

    def test_order_3_is_the_classic_square(self):
        self.assertEqual(odd_magic_square(3), [[8, 1, 6], [3, 5, 7], [4, 9, 2]])

    def test_one_is_in_top_row_middle_column(self):
        for n in (3, 5, 7, 9, 11):
            self.assertEqual(odd_magic_square(n)[0][n // 2], 1)

    def test_events_are_honest_and_one_per_number(self):
        for n in (3, 5, 7, 9, 11):
            events = odd_magic_square_events(n)
            self.assertEqual(len(events), n * n)
            # numbers are placed in order 1, 2, 3, ...
            self.assertEqual([e.value for e in events], list(range(1, n * n + 1)))
            final = self.check_events(events, n, len(PSEUDOCODE))
            self.assertEqual(final, odd_magic_square(n))

    def test_wrap_and_collision_messages_appear(self):
        events = odd_magic_square_events(5)
        text = " ".join(e.message for e in events)
        self.assertIn("wrapped", text)
        self.assertIn("already filled", text)

    def test_even_order_rejected(self):
        for n in (0, 2, 4, 6):
            with self.assertRaises(ValueError):
                odd_magic_square_events(n)


if __name__ == "__main__":
    unittest.main()
