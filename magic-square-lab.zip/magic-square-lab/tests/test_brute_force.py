import os
import threading
import time
import unittest

from algorithms.validation import validate_square
from brute_force.backtracking_search import backtracking_search
from brute_force.naive_search import naive_search, naive_warning, search_space_size
from brute_force.search_result import (CANCELLED, COUNT_LIMIT, ERROR, EXHAUSTED, FOUND,
                                       TIME_LIMIT)


class TestNaiveSearch(unittest.TestCase):
    def test_order_3_finds_a_valid_square(self):
        r = naive_search(3)
        self.assertEqual(r.status, FOUND)
        self.assertTrue(r.finished_honestly)
        self.assertTrue(validate_square(r.square).is_valid)
        self.assertTrue(r.validation.is_valid)
        self.assertTrue(1 <= r.examined <= 362_880)
        self.assertEqual(r.unit, "arrangements")
        self.assertGreater(r.elapsed_seconds, 0)

    def test_order_3_exhaustive_count_is_eight(self):
        r = naive_search(3, collect_all=True)
        self.assertEqual(r.status, EXHAUSTED)
        self.assertEqual(r.examined, 362_880)  # exactly 9!
        self.assertEqual(r.solution_count, 8)
        self.assertEqual(len({tuple(map(tuple, s)) for s in r.all_squares}), 8)
        self.assertTrue(all(validate_square(s).is_valid for s in r.all_squares))

    def test_order_2_has_no_solution_and_says_so(self):
        r = naive_search(2)
        self.assertEqual(r.status, EXHAUSTED)
        self.assertEqual(r.examined, 24)  # 4!
        self.assertIsNone(r.square)
        self.assertIn("none is a magic square", r.message)

    def test_order_1_is_trivial(self):
        r = naive_search(1)
        self.assertEqual(r.status, FOUND)
        self.assertEqual(r.square, [[1]])

    def test_order_4_stops_at_the_safety_limit_honestly(self):
        r = naive_search(4, max_arrangements=10_000)
        self.assertEqual(r.status, COUNT_LIMIT)
        self.assertEqual(r.examined, 10_000)
        self.assertIsNone(r.square)
        self.assertFalse(r.finished_honestly)
        self.assertIn("did NOT finish", r.message)

    def test_time_limit(self):
        r = naive_search(4, time_limit=0.05, max_arrangements=None)
        self.assertEqual(r.status, TIME_LIMIT)
        self.assertIsNone(r.square)
        self.assertLess(r.elapsed_seconds, 5)
        self.assertGreaterEqual(r.elapsed_seconds, 0.05)

    def test_cancel_flag_already_set(self):
        flag = threading.Event()
        flag.set()
        r = naive_search(4, cancel_event=flag, max_arrangements=None)
        self.assertEqual(r.status, CANCELLED)
        self.assertEqual(r.examined, 4096)  # first look at the flag

    def test_cancel_from_another_thread(self):
        flag = threading.Event()
        threading.Timer(0.05, flag.set).start()
        r = naive_search(4, cancel_event=flag, max_arrangements=None, time_limit=30)
        self.assertEqual(r.status, CANCELLED)
        self.assertLess(r.elapsed_seconds, 5)

    def test_warning_for_larger_orders(self):
        self.assertIsNone(naive_warning(3))
        text = naive_warning(4)
        self.assertIn("20,922,789,888,000", text)
        self.assertEqual(search_space_size(3), 362_880)

    def test_invalid_order_reports_error_instead_of_crashing(self):
        self.assertEqual(naive_search(0).status, ERROR)


class TestBacktrackingSearch(unittest.TestCase):
    def test_order_3(self):
        r = backtracking_search(3)
        self.assertEqual(r.status, FOUND)
        self.assertTrue(validate_square(r.square).is_valid)
        self.assertEqual(r.unit, "nodes")
        self.assertGreater(r.examined, 0)

    def test_order_3_pruning_loses_no_solutions(self):
        # The pruned search must find exactly the same 8 squares as the naive search.
        pruned = backtracking_search(3, collect_all=True)
        naive = naive_search(3, collect_all=True)
        self.assertEqual(pruned.status, EXHAUSTED)
        self.assertEqual(pruned.solution_count, 8)
        self.assertEqual({tuple(map(tuple, s)) for s in pruned.all_squares},
                         {tuple(map(tuple, s)) for s in naive.all_squares})
        self.assertLess(pruned.examined, naive.examined / 100)  # and does far less work

    def test_order_4_is_found_quickly(self):
        r = backtracking_search(4, time_limit=60)
        self.assertEqual(r.status, FOUND)
        self.assertTrue(validate_square(r.square).is_valid)
        self.assertTrue(r.validation.is_valid)
        self.assertGreater(r.examined, 0)
        self.assertGreater(r.pruned, 0)
        self.assertLess(r.elapsed_seconds, 30)

    def test_node_counts_are_repeatable(self):
        a = backtracking_search(4)
        b = backtracking_search(4)
        self.assertEqual(a.examined, b.examined)
        self.assertEqual(a.square, b.square)

    def test_all_cell_and_value_orders_find_valid_squares(self):
        for cells in ("row_major", "diagonals_first"):
            for values in ("ascending", "descending"):
                with self.subTest(cells=cells, values=values):
                    r = backtracking_search(4, cell_order=cells, value_order=values)
                    self.assertEqual(r.status, FOUND)
                    self.assertTrue(validate_square(r.square).is_valid)

    def test_unknown_options_give_error_status(self):
        self.assertEqual(backtracking_search(4, cell_order="zigzag").status, ERROR)
        self.assertEqual(backtracking_search(4, value_order="random").status, ERROR)
        self.assertEqual(backtracking_search(0).status, ERROR)

    def test_order_2_exhausts_with_no_solution(self):
        r = backtracking_search(2)
        self.assertEqual(r.status, EXHAUSTED)
        self.assertIsNone(r.square)
        self.assertIn("no magic square exists", r.message)

    def test_order_1(self):
        self.assertEqual(backtracking_search(1).square, [[1]])

    def test_node_limit(self):
        r = backtracking_search(4, max_nodes=500)
        self.assertEqual(r.status, COUNT_LIMIT)
        self.assertEqual(r.examined, 500)
        self.assertIsNone(r.square)
        self.assertIn("did NOT finish", r.message)

    def test_time_limit_is_reported_not_hidden(self):
        r = backtracking_search(6, time_limit=0.05)
        self.assertEqual(r.status, TIME_LIMIT)
        self.assertIsNone(r.square)
        self.assertIsNone(r.validation)
        self.assertFalse(r.finished_honestly)
        self.assertLess(r.elapsed_seconds, 3)

    def test_cancel_from_another_thread(self):
        flag = threading.Event()
        threading.Timer(0.05, flag.set).start()
        r = backtracking_search(6, cancel_event=flag, time_limit=60)
        self.assertEqual(r.status, CANCELLED)
        self.assertLess(r.elapsed_seconds, 5)

    def test_progress_callback_receives_increasing_counts(self):
        seen = []
        backtracking_search(6, time_limit=0.3, progress=seen.append)
        self.assertGreaterEqual(len(seen), 2)
        self.assertEqual(seen, sorted(seen))

    @unittest.skipUnless(os.environ.get("RUN_SLOW_TESTS") == "1",
                         "slow (about 1-2 minutes): set RUN_SLOW_TESTS=1 to run")
    def test_order_4_has_exactly_7040_magic_squares(self):
        r = backtracking_search(4, collect_all=True, time_limit=600)
        self.assertEqual(r.status, EXHAUSTED)
        self.assertEqual(r.solution_count, 7040)
        self.assertEqual(len({tuple(map(tuple, s)) for s in r.all_squares}), 7040)
        self.assertTrue(all(validate_square(s).is_valid for s in r.all_squares))


if __name__ == "__main__":
    unittest.main()
