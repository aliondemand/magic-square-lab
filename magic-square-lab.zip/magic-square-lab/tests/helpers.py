"""Shared helpers for the constructive-algorithm tests."""

import unittest

from algorithms.simulation_events import replay_events
from algorithms.validation import validate_square


class MagicSquareTestCase(unittest.TestCase):
    """Base class with a thorough check that every constructive test reuses."""

    def check_square(self, square, n):
        # Own tiny checks, written separately from the validator module.
        target = n * (n * n + 1) // 2
        self.assertEqual(len(square), n)
        self.assertTrue(all(len(row) == n for row in square))
        flat = [v for row in square for v in row]
        self.assertEqual(sorted(flat), list(range(1, n * n + 1)))  # no gaps, no duplicates
        for r in range(n):
            self.assertEqual(sum(square[r]), target, f"row {r}")
        for c in range(n):
            self.assertEqual(sum(square[r][c] for r in range(n)), target, f"column {c}")
        self.assertEqual(sum(square[i][i] for i in range(n)), target, "main diagonal")
        self.assertEqual(sum(square[i][n - 1 - i] for i in range(n)), target, "secondary diagonal")
        # The reusable validator must agree.
        result = validate_square(square)
        self.assertTrue(result.is_valid, result.summary())
        self.assertEqual(result.magic_constant, target)

    def check_events(self, events, n, pseudocode_length):
        """Events must be well formed and must rebuild exactly the final square."""
        self.assertGreater(len(events), 0)
        for e in events:
            self.assertTrue(e.message)
            self.assertTrue(e.phase)
            self.assertTrue(0 <= e.pseudo_line < pseudocode_length)
            for r, c in e.cells:
                self.assertTrue(0 <= r < n and 0 <= c < n)
        return replay_events(n, events)  # raises ValueError if any event is dishonest
