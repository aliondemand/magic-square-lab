import contextlib
import csv
import io
import tempfile
import unittest
from pathlib import Path

from benchmarks import plot_results, run_benchmarks


class TestBenchmarks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.dir = Path(cls.tmp.name)
        run_benchmarks.run_all(cls.dir, quick=True, limit=0.3, log=lambda *a: None)
        cls.rows = plot_results.read_csv(cls.dir / "results.csv")
        cls.estimates = plot_results.read_csv(cls.dir / "estimates.csv")

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_files_are_written_and_not_empty(self):
        for name in ("results.csv", "estimates.csv", "environment.txt"):
            self.assertGreater((self.dir / name).stat().st_size, 50, name)
        with open(self.dir / "results.csv", newline="", encoding="utf-8") as f:
            self.assertEqual(csv.DictReader(f).fieldnames, run_benchmarks.CSV_COLUMNS)

    def test_environment_is_recorded(self):
        text = (self.dir / "environment.txt").read_text(encoding="utf-8")
        for key in ("operating_system", "python_version", "logical_cpus", "perf_counter"):
            self.assertIn(key, text)

    def test_every_order_3_to_12_was_measured_and_verified(self):
        constructive = [r for r in self.rows if r["group"] == "constructive"]
        measured = {int(r["n"]) for r in constructive}
        self.assertTrue(set(range(3, 13)) <= measured)
        for r in constructive:
            self.assertEqual(r["status"], "FOUND")
            self.assertGreater(float(r["time_mean_s"]), 0)
            self.assertIn("mean of", r["statistic"])
            self.assertIn("independent validator", r["note"])
        for r in constructive:
            if int(r["n"]) > 12:
                self.assertIn("benchmark only", r["in_gui_range"])

    def test_brute_force_rows_exist_with_counts(self):
        naive3 = [r for r in self.rows if r["group"] == "naive" and r["n"] == "3"]
        self.assertEqual(len(naive3), 2)
        full = [r for r in naive3 if "worst case" in r["note"]][0]
        self.assertEqual(full["status"], "EXHAUSTED")
        self.assertEqual(float(full["examined_mean"]), 362_880)
        backtracking = {r["n"]: r for r in self.rows if r["group"] == "backtracking"}
        for n in ("3", "4"):
            self.assertEqual(backtracking[n]["status"], "FOUND")
            self.assertGreater(float(backtracking[n]["examined_mean"]), 0)
            self.assertGreater(float(backtracking[n]["pruned_mean"]), 0)

    def test_unfinished_searches_are_labelled_and_never_called_finished(self):
        limited = [r for r in self.rows if r["status"] in ("TIME_LIMIT", "COUNT_LIMIT")]
        self.assertTrue(limited)
        self.assertTrue(any(r["group"] == "naive" and r["n"] == "4" for r in limited))
        for r in limited:
            self.assertEqual(r["statistic"], "single run")
            self.assertIn("NOT FINISHED", r["note"])
            self.assertEqual(r["time_limit_s"], "0.3")
        table = plot_results.build_table(self.rows, self.estimates, "env")
        self.assertIn("NOT finished (time limit)", table)
        self.assertIn("limit reached", table)

    def test_estimates_are_labelled_as_theory(self):
        self.assertTrue(self.estimates)
        for e in self.estimates:
            self.assertIn("THEORETICAL ESTIMATE", e["kind"])
            self.assertIn("assumption", e)
            self.assertGreater(float(e["estimated_seconds"]), 0)
        years = {int(e["n"]): float(e["estimated_years"]) for e in self.estimates}
        self.assertTrue(years[3] < years[4] < years[5] < years[6])  # estimates grow with n
        table = plot_results.build_table(self.rows, self.estimates, "env")
        self.assertIn("Theoretical estimates (NOT measurements)", table)

    def test_table_and_plots(self):
        with contextlib.redirect_stdout(io.StringIO()):
            plot_results.main(["--input", str(self.dir), "--no-plots"])
        self.assertIn("| Method | n |", (self.dir / "timing_table.md").read_text(encoding="utf-8"))
        try:
            import matplotlib  # noqa: F401
        except ImportError:
            self.skipTest("matplotlib is not installed")
        with contextlib.redirect_stdout(io.StringIO()):
            plot_results.main(["--input", str(self.dir)])
        for name in ("time_vs_order.png", "constructive_scaling.png"):
            data = (self.dir / name).read_bytes()
            self.assertTrue(data.startswith(b"\x89PNG"), name)
            self.assertGreater(len(data), 5000, name)

    def test_bad_arguments_are_rejected(self):
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            run_benchmarks.main(["--limit", "0"])

    def test_time_formatting(self):
        self.assertEqual(plot_results.fmt_time(0.0000225), "22.5 us")
        self.assertEqual(plot_results.fmt_time(0.0334), "33.400 ms")
        self.assertEqual(plot_results.fmt_time(12.5), "12.500 s")


if __name__ == "__main__":
    unittest.main()
