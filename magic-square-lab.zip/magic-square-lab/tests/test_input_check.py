import unittest

from algorithms.input_check import (InvalidInputError, UnsupportedOrderError,
                                    parse_order)


class TestParseOrder(unittest.TestCase):
    def test_every_required_order_is_accepted(self):
        for n in range(3, 13):
            self.assertEqual(parse_order(str(n)), n)

    def test_spaces_and_plus_sign_are_tolerated(self):
        self.assertEqual(parse_order("  6 "), 6)
        self.assertEqual(parse_order("+7"), 7)
        self.assertEqual(parse_order("012"), 12)
        self.assertEqual(parse_order(5), 5)

    def test_invalid_inputs(self):
        for text in ("", "   ", "abc", "six", "3a", "1,5", "5 5", "nan", "inf", "1e1",
                     "4.5", "4.0", ".5", "5.", "-3", "-1", "0", "00", None, 3.5, True, [3]):
            with self.subTest(text=text):
                with self.assertRaises(InvalidInputError) as ctx:
                    parse_order(text)
                self.assertTrue(str(ctx.exception))

    def test_unsupported_orders(self):
        for text in ("1", "2", "13", "100", "99999999999999999999", "9" * 5000):
            with self.subTest(text=text[:12]):
                with self.assertRaises(UnsupportedOrderError) as ctx:
                    parse_order(text)
                self.assertTrue(str(ctx.exception))

    def test_unsupported_and_invalid_are_distinguished(self):
        self.assertEqual(InvalidInputError.kind, "invalid_input")
        self.assertEqual(UnsupportedOrderError.kind, "unsupported_order")
        self.assertFalse(issubclass(InvalidInputError, UnsupportedOrderError))
        self.assertFalse(issubclass(UnsupportedOrderError, InvalidInputError))

    def test_messages_explain_orders_1_and_2(self):
        with self.assertRaises(UnsupportedOrderError) as one:
            parse_order("1")
        self.assertIn("trivial", str(one.exception))
        with self.assertRaises(UnsupportedOrderError) as two:
            parse_order("2")
        self.assertIn("No magic square of order 2", str(two.exception))

    def test_negative_huge_number_is_invalid_not_unsupported(self):
        with self.assertRaises(InvalidInputError):
            parse_order("-" + "9" * 50)


if __name__ == "__main__":
    unittest.main()
