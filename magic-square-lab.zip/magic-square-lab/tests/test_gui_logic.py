"""Tests for the GUI logic that needs no window: controller and text helpers."""

import unittest

from algorithms.dispatcher import construct
from algorithms.simulation_events import replay_events
from brute_force import search_result as sr
from gui import formatting as fmt
from gui.simulation_controller import (FINISHED, IDLE, PAUSED, READY, RUNNING,
                                       SimulationController)


class FakeScheduler:
    """Stands in for the Tk root: stores callbacks so a test can fire them by hand."""

    def __init__(self):
        self.pending = {}
        self.next_id = 0
        self.delays = []

    def after(self, ms, func):
        self.next_id += 1
        self.pending[self.next_id] = func
        self.delays.append(ms)
        return self.next_id

    def after_cancel(self, ident):
        self.pending.pop(ident, None)

    def fire_oldest(self):
        ident = min(self.pending)
        self.pending.pop(ident)()

    def fire_all_ever_scheduled(self, callbacks):
        for cb in callbacks:
            cb()


def make(n=3):
    scheduler = FakeScheduler()
    log = {"steps": [], "resets": 0, "states": []}
    controller = SimulationController(
        scheduler,
        on_step=lambda i, t, e, g: log["steps"].append((i, t, e, g)),
        on_reset=lambda g: log.__setitem__("resets", log["resets"] + 1),
        on_state_change=lambda s: log["states"].append(s),
        delay_ms=123,
    )
    result = construct(n)
    controller.load(n, result.events)
    return controller, scheduler, log, result


class TestSimulationController(unittest.TestCase):
    def test_load_makes_it_ready_with_an_empty_grid(self):
        c, s, log, r = make(3)
        self.assertEqual(c.state, READY)
        self.assertEqual(c.grid, [[0] * 3 for _ in range(3)])
        self.assertEqual(c.total, 9)

    def test_nothing_loaded_is_idle(self):
        c, s, log, r = make(3)
        c.clear()
        self.assertEqual(c.state, IDLE)
        c.start(); c.step(); c.pause()      # all ignored
        self.assertEqual(log["steps"], [])

    def test_step_applies_exactly_one_event(self):
        c, s, log, r = make(5)
        c.step()
        self.assertEqual(c.index, 1)
        self.assertEqual(len(log["steps"]), 1)
        self.assertEqual(c.state, PAUSED)
        self.assertEqual(sum(1 for row in c.grid for v in row if v), 1)
        c.step()
        self.assertEqual(c.index, 2)
        self.assertEqual(sum(1 for row in c.grid for v in row if v), 2)
        self.assertEqual(s.pending, {})  # step never creates a timer

    def test_start_plays_to_the_end_with_the_requested_delay(self):
        c, s, log, r = make(4)
        c.start()
        self.assertEqual(c.state, RUNNING)
        while s.pending:
            s.fire_oldest()
        self.assertEqual(c.state, FINISHED)
        self.assertEqual(c.index, c.total)
        self.assertEqual(c.grid, r.square)
        self.assertEqual(s.delays[0], 0)
        self.assertTrue(all(d == 123 for d in s.delays[1:]))

    def test_every_step_callback_gets_a_copy_of_the_grid(self):
        c, s, log, r = make(3)
        c.step()
        snapshot = log["steps"][0][3]
        c.step()
        self.assertEqual(sum(1 for row in snapshot for v in row if v), 1)  # unchanged by later steps

    def test_pause_stops_and_resume_continues(self):
        c, s, log, r = make(5)
        c.start()
        for _ in range(3):
            s.fire_oldest()
        c.pause()
        self.assertEqual(c.state, PAUSED)
        self.assertEqual(s.pending, {})
        done = c.index
        c.start()                           # resume
        self.assertEqual(c.state, RUNNING)
        while s.pending:
            s.fire_oldest()
        self.assertEqual(c.state, FINISHED)
        self.assertGreater(c.index, done)
        self.assertEqual(c.grid, r.square)

    def test_start_twice_never_creates_two_timers(self):
        c, s, log, r = make(5)
        c.start(); c.start(); c.start()
        self.assertEqual(len(s.pending), 1)

    def test_step_is_ignored_while_running(self):
        c, s, log, r = make(5)
        c.start()
        c.step()
        self.assertEqual(c.index, 0)

    def test_reset_clears_and_cancels_pending_ticks(self):
        c, s, log, r = make(5)
        c.start()
        stale_callback = s.pending[min(s.pending)]  # a tick that is already scheduled
        c.reset()
        self.assertEqual(c.state, READY)
        self.assertEqual(c.index, 0)
        self.assertEqual(c.grid, [[0] * 5 for _ in range(5)])
        self.assertEqual(s.pending, {})
        stale_callback()                    # even if it still fires, it must do nothing
        self.assertEqual(c.index, 0)
        self.assertEqual(c.state, READY)

    def test_reset_after_finishing_allows_a_replay(self):
        c, s, log, r = make(3)
        c.start()
        while s.pending:
            s.fire_oldest()
        self.assertEqual(c.state, FINISHED)
        c.reset()
        self.assertEqual(c.state, READY)
        c.start()
        while s.pending:
            s.fire_oldest()
        self.assertEqual(c.grid, r.square)

    def test_a_stale_tick_cannot_touch_a_newer_simulation(self):
        c, s, log, r = make(5)
        c.start()
        old_tick = s.pending[min(s.pending)]
        second = construct(7)
        c.load(7, second.events)             # a new Construct while the old one was running
        old_tick()
        self.assertEqual(c.index, 0)
        self.assertEqual(c.n, 7)
        self.assertEqual(c.state, READY)

    def test_stale_tick_after_pause_does_nothing(self):
        c, s, log, r = make(5)
        c.start()
        old_tick = s.pending[min(s.pending)]
        c.pause()
        old_tick()
        self.assertEqual(c.index, 0)

    def test_finished_state_ignores_start_and_step(self):
        c, s, log, r = make(3)
        c.start()
        while s.pending:
            s.fire_oldest()
        count = len(log["steps"])
        c.start(); c.step()
        self.assertEqual(len(log["steps"]), count)

    def test_replay_matches_for_every_required_order(self):
        for n in range(3, 13):
            c, s, log, r = make(n)
            c.start()
            while s.pending:
                s.fire_oldest()
            self.assertEqual(c.state, FINISHED, n)
            self.assertEqual(c.grid, replay_events(n, r.events), n)

    def test_shutdown_cancels_timers(self):
        c, s, log, r = make(5)
        c.start()
        c.shutdown()
        self.assertEqual(s.pending, {})

    def test_set_delay(self):
        c, s, log, r = make(5)
        c.set_delay(40)
        c.start()
        s.fire_oldest(); s.fire_oldest()
        self.assertEqual(s.delays[-1], 40)


class TestFormatting(unittest.TestCase):
    def test_seconds(self):
        self.assertEqual(fmt.format_seconds(0.0123456), "12.346 ms")
        self.assertEqual(fmt.format_seconds(2.5), "2.500 s")
        self.assertEqual(fmt.format_seconds(None), "-")

    def test_speed_levels(self):
        delays = [fmt.delay_for_speed(i) for i in range(1, 11)]
        self.assertEqual(delays, sorted(delays, reverse=True))   # faster level = smaller delay
        self.assertEqual(fmt.delay_for_speed(-5), fmt.SPEED_DELAYS_MS[0])
        self.assertEqual(fmt.delay_for_speed(99), fmt.SPEED_DELAYS_MS[-1])

    def test_time_limit_accepts_good_values(self):
        self.assertEqual(fmt.parse_time_limit("30"), 30.0)
        self.assertEqual(fmt.parse_time_limit(" 0.5 "), 0.5)

    def test_time_limit_rejects_bad_values(self):
        for bad in ("", "  ", "abc", "0", "-3", "nan", "inf", "1e9", "3601"):
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError) as ctx:
                    fmt.parse_time_limit(bad)
                self.assertTrue(str(ctx.exception))

    def test_status_text_is_honest_about_unfinished_searches(self):
        self.assertIn("NOT finished", fmt.describe_status(sr.TIME_LIMIT))
        self.assertIn("NOT finished", fmt.describe_status(sr.COUNT_LIMIT))
        self.assertIn("not finished", fmt.describe_status(sr.CANCELLED))

    def test_validation_text(self):
        from algorithms.validation import validate_square
        good = validate_square(construct(4).square)
        self.assertIn("VALID", fmt.describe_validation(good))
        bad = validate_square([[1, 2], [3, 4]])
        self.assertIn("NOT a magic square", fmt.describe_validation(bad))
        self.assertEqual(fmt.describe_validation(None), "-")


if __name__ == "__main__":
    unittest.main()
