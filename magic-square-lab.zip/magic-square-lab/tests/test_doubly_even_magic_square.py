import unittest

from algorithms.doubly_even_magic_square import (PSEUDOCODE,
                                                 doubly_even_magic_square,
                                                 doubly_even_magic_square_events,
                                                 is_marked)
from algorithms.simulation_events import COMPLEMENT, PLACE
from tests.helpers import MagicSquareTestCase


class TestDoublyEvenMagicSquare(MagicSquareTestCase):
    def test_required_orders(self):
        for n in (4, 8, 12):
            with self.subTest(n=n):
                self.check_square(doubly_even_magic_square(n), n)

    def test_order_4_known_result(self):
        self.assertEqual(doubly_even_magic_square(4),
                         [[16, 2, 3, 13], [5, 11, 10, 8], [9, 7, 6, 12], [4, 14, 15, 1]])

    def test_events_two_phases(self):
        for n in (4, 8, 12):
            events = doubly_even_magic_square_events(n)
            places = [e for e in events if e.kind == PLACE]
            complements = [e for e in events if e.kind == COMPLEMENT]
            self.assertEqual(len(places), n * n)
            self.assertEqual(len(complements), n * n // 2)  # half the cells are on diagonals
            # all PLACE events come before all COMPLEMENT events
            self.assertEqual(events[: n * n], places)
            for e in complements:
                self.assertEqual(e.value + e.old_value, n * n + 1)
                self.assertTrue(is_marked(*e.cells[0]))
            final = self.check_events(events, n, len(PSEUDOCODE))
            self.assertEqual(final, doubly_even_magic_square(n))

    def test_invalid_orders_rejected(self):
        for n in (0, 3, 5, 6, 10):
            with self.assertRaises(ValueError):
                doubly_even_magic_square_events(n)


if __name__ == "__main__":
    unittest.main()
