# Benchmark results

## Test environment

```
Benchmark environment (recorded automatically by run_benchmarks.py)

date_utc: 2026-10-26 06:16:25
operating_system: Linux-6.18.44-fc-v153-x86_64-with-glibc2.39
machine: x86_64
processor: x86_64
logical_cpus: 1
python_version: 3.12.3
python_implementation: CPython
timer: time.perf_counter()

Settings used:
quick_mode: False
time_limit_for_hard_searches_s: 10.0
constructive_repeats: 200
```

## Measured results

Times use `time.perf_counter()` around the algorithm only (no animation). Rows marked 'NOT finished' show the limit that stopped the search, not a completed runtime.

| Method | n | Runs | Result | Time | Examined | Pruned |
|---|---|---|---|---|---|---|
| Siamese method (de la Loubere) | 3 | 200 (mean of 200 runs) | found a valid square | 22.4 us | 9 events | - |
| Diagonal / complement method | 4 | 200 (mean of 200 runs) | found a valid square | 58.3 us | 24 events | - |
| Siamese method (de la Loubere) | 5 | 200 (mean of 200 runs) | found a valid square | 65.5 us | 25 events | - |
| Strachey's method | 6 | 200 (mean of 200 runs) | found a valid square | 125.7 us | 39 events | - |
| Siamese method (de la Loubere) | 7 | 200 (mean of 200 runs) | found a valid square | 149.9 us | 49 events | - |
| Diagonal / complement method | 8 | 200 (mean of 200 runs) | found a valid square | 203.5 us | 96 events | - |
| Siamese method (de la Loubere) | 9 | 200 (mean of 200 runs) | found a valid square | 210.6 us | 81 events | - |
| Strachey's method | 10 | 200 (mean of 200 runs) | found a valid square | 427.5 us | 115 events | - |
| Siamese method (de la Loubere) | 11 | 200 (mean of 200 runs) | found a valid square | 316.3 us | 121 events | - |
| Diagonal / complement method | 12 | 200 (mean of 200 runs) | found a valid square | 495.6 us | 216 events | - |
| Diagonal / complement method | 16 | 20 (mean of 20 runs) | found a valid square | 795.0 us | 384 events | - |
| Diagonal / complement method | 20 | 20 (mean of 20 runs) | found a valid square | 1.277 ms | 600 events | - |
| Diagonal / complement method | 24 | 20 (mean of 20 runs) | found a valid square | 1.929 ms | 864 events | - |
| Strachey's method | 30 | 20 (mean of 20 runs) | found a valid square | 4.718 ms | 1,095 events | - |
| Strachey's method | 50 | 20 (mean of 20 runs) | found a valid square | 8.740 ms | 3,075 events | - |
| Diagonal / complement method | 100 | 20 (mean of 20 runs) | found a valid square | 46.996 ms | 15,000 events | - |
| Naive permutation search | 3 | 10 (mean of 10 runs) | found a valid square | 42.049 ms | 69,075 arrangements | - |
| Naive permutation search | 3 | 3 (mean of 3 runs) | finished (whole space tried) | 221.031 ms | 362,880 arrangements | - |
| Naive permutation search | 4 | 1 (single run) | NOT finished (time limit) | > 10.001 s (limit reached) | 19,394,560 arrangements | - |
| Backtracking with pruning | 3 | 50 (mean of 50 runs) | found a valid square | 100.4 us | 82 nodes | 288 |
| Backtracking with pruning | 4 | 10 (mean of 10 runs) | found a valid square | 33.432 ms | 28,970 nodes | 126,254 |
| Backtracking with pruning | 5 | 1 (single run) | NOT finished (time limit) | > 10.000 s (limit reached) | 9,187,328 nodes | 69,426,760 |
| Backtracking with pruning | 6 | 1 (single run) | NOT finished (time limit) | > 10.001 s (limit reached) | 10,496,000 nodes | 125,719,470 |
| Backtracking with pruning | 7 | 1 (single run) | NOT finished (time limit) | > 10.001 s (limit reached) | 10,279,936 nodes | 214,100,101 |
| Backtracking with pruning | 8 | 1 (single run) | NOT finished (time limit) | > 10.001 s (limit reached) | 9,582,592 nodes | 229,371,444 |

## Theoretical estimates (NOT measurements)

Assumption: the naive search keeps the speed measured above and must try all (n*n)! arrangements (worst case).

| Method | n | (n*n)! arrangements | Estimated time (seconds) | Estimated time (years) |
|---|---|---|---|---|
| Naive permutation search | 3 | 3.629e+05 | 1.871e-01 | 5.929e-09 |
| Naive permutation search | 4 | 2.092e+13 | 1.079e+07 | 3.419e-01 |
| Naive permutation search | 5 | 1.551e+25 | 7.998e+18 | 2.534e+11 |
| Naive permutation search | 6 | 3.720e+41 | 1.918e+35 | 6.078e+27 |
