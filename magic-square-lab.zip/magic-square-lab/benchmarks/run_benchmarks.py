"""Benchmarks: constructive algorithms vs. both brute-force searches.

Run from the project folder:
    python benchmarks/run_benchmarks.py                 (normal run, about 1-2 minutes)
    python benchmarks/run_benchmarks.py --quick         (short test run, a few seconds)
    python benchmarks/run_benchmarks.py --limit 20      (give timed-out searches 20 s each)

What is measured
----------------
* Every time is measured with time.perf_counter() around the algorithm only.
  No animation delay and no GUI is involved.
* Constructive timings use exactly the same function as the GUI (construct()),
  so the numbers are comparable with the "Time taken" box.
* Repeated runs are averaged. Every row says whether it is "mean of N runs"
  or a "single run".
* A search that hits its time limit is recorded with status TIME_LIMIT. Its
  time is just the limit, NOT a completed runtime.
* Nothing is typed in by hand: results.csv, estimates.csv and environment.txt
  are written by this script.
"""

from __future__ import annotations

import argparse
import csv
import datetime
import math
import os
import platform
import statistics
import sys
import time
from pathlib import Path
from typing import Dict, List

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from algorithms.dispatcher import classify_order, construct  # noqa: E402
from algorithms.validation import validate_square  # noqa: E402
from brute_force.backtracking_search import backtracking_search  # noqa: E402
from brute_force.naive_search import naive_search, search_space_size  # noqa: E402
from brute_force.search_result import (BACKTRACKING, COUNT_LIMIT, EXHAUSTED, FOUND,  # noqa: E402
                                       NAIVE, STRATEGY_NAMES, TIME_LIMIT)

CSV_COLUMNS = ["group", "method", "n", "category", "runs", "statistic", "status",
               "time_mean_s", "time_min_s", "time_max_s", "time_stdev_s",
               "examined_mean", "unit", "pruned_mean", "time_limit_s", "in_gui_range", "note"]
ESTIMATE_COLUMNS = ["method", "n", "search_space", "assumed_rate_per_s", "estimated_seconds",
                    "estimated_years", "kind", "assumption"]

GUI_MAX_ORDER = 12
SECONDS_PER_YEAR = 365.25 * 24 * 3600


# ----------------------------------------------------------------------------
# helpers
# ----------------------------------------------------------------------------
def collect_environment() -> Dict[str, str]:
    """Facts about the machine and Python that produced the numbers (never invented)."""
    return {
        "date_utc": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
        "operating_system": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor() or "(not reported by the operating system)",
        "logical_cpus": str(os.cpu_count()),
        "python_version": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "timer": "time.perf_counter()",
    }


def _stats(times: List[float]) -> Dict[str, float]:
    return {
        "time_mean_s": statistics.fmean(times),
        "time_min_s": min(times),
        "time_max_s": max(times),
        "time_stdev_s": statistics.stdev(times) if len(times) > 1 else 0.0,
    }


def _row(**values) -> Dict[str, object]:
    row = {column: "" for column in CSV_COLUMNS}
    row.update(values)
    return row


def _category(n: int) -> str:
    try:
        return classify_order(n)
    except ValueError:
        return ""


# ----------------------------------------------------------------------------
# constructive algorithms
# ----------------------------------------------------------------------------
def benchmark_constructive(orders, repeats: int, in_gui_range_max: int = GUI_MAX_ORDER) -> List[Dict]:
    rows = []
    for n in orders:
        construct(n)  # warm-up run, not counted
        times = []
        for _ in range(repeats):
            times.append(construct(n).elapsed_seconds)  # same timer as the GUI "Time taken" box
        result = construct(n)
        verdict = validate_square(result.square)
        if not verdict.is_valid:  # never record timings of a wrong algorithm
            raise RuntimeError(f"constructive algorithm gave an invalid square for n={n}: {verdict.errors}")
        rows.append(_row(
            group="constructive", method=result.algorithm_name, n=n, category=result.category,
            runs=repeats, statistic=f"mean of {repeats} runs", status="FOUND",
            examined_mean=len(result.events), unit="events", pruned_mean="",
            in_gui_range="yes" if n <= in_gui_range_max else "no (benchmark only)",
            note="result verified by the independent validator", **_stats(times)))
    return rows


# ----------------------------------------------------------------------------
# brute force
# ----------------------------------------------------------------------------
def _search_row(strategy, n, results, statistic, limit, note="") -> Dict:
    times = [r.elapsed_seconds for r in results]
    statuses = {r.status for r in results}
    status = results[0].status if len(statuses) == 1 else "MIXED:" + "/".join(sorted(statuses))
    for r in results:
        if r.status == FOUND and not (r.validation and r.validation.is_valid):
            raise RuntimeError("a search reported a square that failed validation")
    return _row(
        group=strategy, method=STRATEGY_NAMES[strategy], n=n, category=_category(n),
        runs=len(results), statistic=statistic, status=status,
        examined_mean=statistics.fmean(r.examined for r in results), unit=results[0].unit,
        pruned_mean=statistics.fmean(r.pruned for r in results) if strategy == BACKTRACKING else "",
        time_limit_s=limit if limit is not None else "",
        in_gui_range="yes" if n <= GUI_MAX_ORDER else "no", note=note, **_stats(times))


def benchmark_naive(repeats: int, limit: float, full_runs: int) -> List[Dict]:
    rows = []
    # Order 3, stop at the first magic square found (deterministic order, so the count repeats).
    results = [naive_search(3, time_limit=None, max_arrangements=None) for _ in range(repeats)]
    rows.append(_search_row(NAIVE, 3, results, f"mean of {repeats} runs", None,
                            "stops at the first magic square (permutations in lexicographic order)"))
    # Order 3, whole space: the worst case of exactly 9! arrangements.
    results = [naive_search(3, collect_all=True, time_limit=None, max_arrangements=None)
               for _ in range(full_runs)]
    rows.append(_search_row(NAIVE, 3, results, f"mean of {full_runs} runs", None,
                            "worst case: ALL 9! = 362,880 arrangements tried, 8 magic squares found"))
    # Order 4: cannot finish. One run until the time limit.
    result = naive_search(4, time_limit=limit, max_arrangements=None)
    rows.append(_search_row(NAIVE, 4, [result], "single run", limit,
                            "NOT FINISHED: stopped by the time limit; time shown is the limit, not a runtime"
                            if result.status == TIME_LIMIT else ""))
    return rows


def benchmark_backtracking(repeats3: int, repeats4: int, hard_orders, limit: float) -> List[Dict]:
    rows = []
    results = [backtracking_search(3) for _ in range(repeats3)]
    rows.append(_search_row(BACKTRACKING, 3, results, f"mean of {repeats3} runs", None,
                            "stops at the first magic square"))
    results = [backtracking_search(4) for _ in range(repeats4)]
    rows.append(_search_row(BACKTRACKING, 4, results, f"mean of {repeats4} runs", None,
                            "stops at the first magic square"))
    for n in hard_orders:
        result = backtracking_search(n, time_limit=limit)
        note = ("NOT FINISHED: stopped by the time limit; time shown is the limit, not a runtime"
                if result.status == TIME_LIMIT else "")
        rows.append(_search_row(BACKTRACKING, n, [result], "single run", limit, note))
    return rows


def make_estimates(rows: List[Dict], orders=(3, 4, 5, 6)) -> List[Dict]:
    """THEORETICAL estimates for naive search, based on the measured arrangements per second.

    Assumption: the speed measured in the naive order-4 run (arrangements per second)
    stays the same, and the worst case needs every one of the (n*n)! arrangements.
    """
    source = next((r for r in rows if r["group"] == NAIVE and r["n"] == 4), None)
    if source is None or not source["time_mean_s"]:
        return []
    rate = float(source["examined_mean"]) / float(source["time_mean_s"])
    estimates = []
    for n in orders:
        space = search_space_size(n)
        seconds = space / rate
        estimates.append({
            "method": STRATEGY_NAMES[NAIVE], "n": n, "search_space": f"{space:.6e}",
            "assumed_rate_per_s": f"{rate:.0f}", "estimated_seconds": f"{seconds:.6e}",
            "estimated_years": f"{seconds / SECONDS_PER_YEAR:.6e}", "kind": "THEORETICAL ESTIMATE (worst case)",
            "assumption": f"constant speed of {rate:,.0f} arrangements/s measured on this machine for "
                          f"naive order 4; every one of the (n*n)! arrangements must be tried"})
    return estimates


# ----------------------------------------------------------------------------
# writing files
# ----------------------------------------------------------------------------
def write_csv(path: Path, rows: List[Dict], columns: List[str]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            writer.writerow({c: row.get(c, "") for c in columns})


def write_environment(path: Path, environment: Dict[str, str], settings: Dict[str, object]) -> None:
    lines = ["Benchmark environment (recorded automatically by run_benchmarks.py)", ""]
    lines += [f"{key}: {value}" for key, value in environment.items()]
    lines += ["", "Settings used:"] + [f"{key}: {value}" for key, value in settings.items()]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def run_all(output_dir: Path, quick: bool = False, limit: float = 10.0, log=print) -> Dict[str, Path]:
    """Run every benchmark and write results.csv, estimates.csv and environment.txt."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    if quick:
        limit = min(limit, 0.5)
        constructive_repeats, scaling_repeats = 10, 3
        naive_repeats, naive_full_runs = 2, 1
        bt3_repeats, bt4_repeats, hard = 3, 2, (5, 6)
        scaling_orders = (16, 30)
    else:
        constructive_repeats, scaling_repeats = 200, 20
        naive_repeats, naive_full_runs = 10, 3
        bt3_repeats, bt4_repeats, hard = 50, 10, (5, 6, 7, 8)
        scaling_orders = (16, 20, 24, 30, 50, 100)

    rows: List[Dict] = []
    log("Constructive algorithms, orders 3-12 ...")
    rows += benchmark_constructive(range(3, 13), constructive_repeats)
    log("Constructive algorithms, larger orders (benchmark only) ...")
    rows += benchmark_constructive(scaling_orders, scaling_repeats)
    log(f"Naive search (order 4 gets {limit:g} s) ...")
    rows += benchmark_naive(naive_repeats, limit, naive_full_runs)
    log(f"Backtracking (orders {list(hard)} get {limit:g} s each) ...")
    rows += benchmark_backtracking(bt3_repeats, bt4_repeats, hard, limit)

    estimates = make_estimates(rows)
    environment = collect_environment()
    settings = {"quick_mode": quick, "time_limit_for_hard_searches_s": limit,
                "constructive_repeats": constructive_repeats}
    paths = {"results": output_dir / "results.csv", "estimates": output_dir / "estimates.csv",
             "environment": output_dir / "environment.txt"}
    write_csv(paths["results"], rows, CSV_COLUMNS)
    write_csv(paths["estimates"], estimates, ESTIMATE_COLUMNS)
    write_environment(paths["environment"], environment, settings)
    log(f"Wrote {paths['results']}, {paths['estimates']} and {paths['environment']}")
    return paths


def main(argv=None) -> None:
    parser = argparse.ArgumentParser(description="Run the magic square benchmarks.")
    parser.add_argument("--quick", action="store_true", help="short run for testing (not for the report)")
    parser.add_argument("--limit", type=float, default=10.0,
                        help="time limit in seconds for searches that cannot finish (default 10)")
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent,
                        help="folder for the output files (default: the benchmarks folder)")
    args = parser.parse_args(argv)
    if args.limit <= 0:
        parser.error("--limit must be greater than 0")
    run_all(args.output, quick=args.quick, limit=args.limit)


if __name__ == "__main__":
    main()
