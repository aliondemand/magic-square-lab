"""Turns results.csv into a table and graphs for the report.

Run (after run_benchmarks.py):
    python benchmarks/plot_results.py

Writes, next to results.csv:
    timing_table.md          table of measured results + clearly labelled estimates
    time_vs_order.png        execution time and work done versus order n (log scale)
    constructive_scaling.png constructive time versus n*n (shows the O(n^2) behaviour)

Needs matplotlib (see requirements.txt). The table works without it.
"""

from __future__ import annotations

import argparse
import csv
import math
import sys
from pathlib import Path
from typing import Dict, List

HERE = Path(__file__).resolve().parent


def read_csv(path: Path) -> List[Dict[str, str]]:
    with open(path, newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def fmt_time(seconds: float) -> str:
    if seconds < 1e-3:
        return f"{seconds * 1e6:.1f} us"
    if seconds < 1:
        return f"{seconds * 1e3:.3f} ms"
    return f"{seconds:.3f} s"


def fmt_count(value: str) -> str:
    return f"{float(value):,.0f}" if value not in ("", None) else "-"


def describe_row(row: Dict[str, str]) -> Dict[str, str]:
    """Turn one CSV row into the cells of a table row, labelling unfinished searches clearly."""
    mean = float(row["time_mean_s"])
    status = row["status"]
    if status == "TIME_LIMIT":
        result, time_text = "NOT finished (time limit)", f"> {fmt_time(mean)} (limit reached)"
    elif status == "COUNT_LIMIT":
        result, time_text = "NOT finished (safety limit)", f"> {fmt_time(mean)} (limit reached)"
    elif status == "EXHAUSTED":
        result, time_text = "finished (whole space tried)", fmt_time(mean)
    else:
        result, time_text = "found a valid square", fmt_time(mean)
    return {"method": row["method"], "n": row["n"], "runs": f"{row['runs']} ({row['statistic']})",
            "result": result, "time": time_text,
            "examined": f"{fmt_count(row['examined_mean'])} {row['unit']}",
            "pruned": fmt_count(row["pruned_mean"]) if row["pruned_mean"] else "-",
            "note": row["note"]}


def build_table(rows, estimates, environment_text: str) -> str:
    out = ["# Benchmark results", "", "## Test environment", "", "```", environment_text.strip(), "```", ""]
    out += ["## Measured results", "",
            "Times use `time.perf_counter()` around the algorithm only (no animation). "
            "Rows marked 'NOT finished' show the limit that stopped the search, not a completed runtime.", ""]
    out += ["| Method | n | Runs | Result | Time | Examined | Pruned |", "|---|---|---|---|---|---|---|"]
    for row in rows:
        d = describe_row(row)
        out.append(f"| {d['method']} | {d['n']} | {d['runs']} | {d['result']} | {d['time']} | "
                   f"{d['examined']} | {d['pruned']} |")
    if estimates:
        out += ["", "## Theoretical estimates (NOT measurements)", "",
                "Assumption: the naive search keeps the speed measured above and must try all (n*n)! "
                "arrangements (worst case).", "",
                "| Method | n | (n*n)! arrangements | Estimated time (seconds) | Estimated time (years) |",
                "|---|---|---|---|---|"]
        for e in estimates:
            out.append(f"| {e['method']} | {e['n']} | {float(e['search_space']):.3e} | "
                       f"{float(e['estimated_seconds']):.3e} | {float(e['estimated_years']):.3e} |")
    return "\n".join(out) + "\n"


def make_plots(rows, out_dir: Path) -> List[Path]:
    import matplotlib
    matplotlib.use("Agg")  # draw to a file, no window needed
    import matplotlib.pyplot as plt

    def pick(group, predicate=lambda r: True):
        return [r for r in rows if r["group"] == group and predicate(r)]

    constructive = [r for r in pick("constructive", lambda r: int(r["n"]) <= 12)]
    naive_first = pick("naive", lambda r: "worst case" not in r["note"] and r["status"] == "FOUND")
    naive_full = pick("naive", lambda r: "worst case" in r["note"])
    naive_limit = pick("naive", lambda r: r["status"] in ("TIME_LIMIT", "COUNT_LIMIT"))
    bt_found = pick("backtracking", lambda r: r["status"] == "FOUND")
    bt_limit = pick("backtracking", lambda r: r["status"] in ("TIME_LIMIT", "COUNT_LIMIT"))

    def xs(rs): return [int(r["n"]) for r in rs]
    def ts(rs): return [float(r["time_mean_s"]) for r in rs]
    def es(rs): return [float(r["examined_mean"]) for r in rs]

    paths = []
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5.2))

    # --- left: time versus n -------------------------------------------------------
    ax1.plot(xs(constructive), ts(constructive), "-o", color="#2563eb", label="Constructive (Siamese / complement / Strachey)")
    if bt_found:
        ax1.plot(xs(bt_found), ts(bt_found), "s", color="#16a34a", markersize=8, label="Backtracking: found a square")
    if bt_limit:
        ax1.plot(xs(bt_limit), ts(bt_limit), "v", markerfacecolor="white", color="#16a34a", markersize=9,
                 label="Backtracking: NOT finished (limit reached)")
    if naive_first:
        ax1.plot(xs(naive_first), ts(naive_first), "D", color="#dc2626", markersize=8, label="Naive: found a square")
    if naive_full:
        ax1.plot(xs(naive_full), ts(naive_full), "P", color="#9a3412", markersize=9, label="Naive: all 9! arrangements tried")
    if naive_limit:
        ax1.plot(xs(naive_limit), ts(naive_limit), "v", markerfacecolor="white", color="#dc2626", markersize=9,
                 label="Naive: NOT finished (limit reached)")
    ax1.set_yscale("log")
    ax1.set_xlabel("Order n")
    ax1.set_ylabel("Time (seconds, log scale)")
    ax1.set_title("Execution time versus order")
    ax1.grid(True, which="both", alpha=0.3)
    ax1.legend(fontsize=8, loc="center right")
    ax1.set_xticks(range(3, 13))
    ax1.text(0.01, 0.01, "Hollow markers: the search was STOPPED at its limit;\nthe true time is larger than shown.",
             transform=ax1.transAxes, fontsize=8, va="bottom", color="#444444")

    # --- right: work done versus n ----------------------------------------------------
    if bt_found:
        ax2.plot(xs(bt_found), es(bt_found), "s", color="#16a34a", markersize=8, label="Backtracking nodes (found)")
    if bt_limit:
        ax2.plot(xs(bt_limit), es(bt_limit), "v", markerfacecolor="white", color="#16a34a", markersize=9,
                 label="Backtracking nodes (NOT finished)")
    if naive_first:
        ax2.plot(xs(naive_first), es(naive_first), "D", color="#dc2626", markersize=8, label="Naive arrangements (found)")
    if naive_limit:
        ax2.plot(xs(naive_limit), es(naive_limit), "v", markerfacecolor="white", color="#dc2626", markersize=9,
                 label="Naive arrangements (NOT finished)")
    max_n = max([3] + xs(bt_limit) + xs(naive_limit))
    orders = list(range(3, max_n + 1))
    ax2.plot(orders, [math.factorial(n * n) for n in orders], "--", color="#6b7280",
             label="(n*n)! search space (theory, not measured)")
    ax2.set_yscale("log")
    ax2.set_xlabel("Order n")
    ax2.set_ylabel("Arrangements / nodes examined (log scale)")
    ax2.set_title("Work done versus order")
    ax2.grid(True, which="both", alpha=0.3)
    ax2.legend(fontsize=8, loc="upper left")
    ax2.set_xticks(orders)

    fig.tight_layout()
    path = out_dir / "time_vs_order.png"
    fig.savefig(path, dpi=150)
    plt.close(fig)
    paths.append(path)

    # --- second figure: constructive scaling ---------------------------------------------
    everything = pick("constructive")
    if len(everything) >= 3:
        fig, ax = plt.subplots(figsize=(6.5, 4.6))
        pts = sorted((int(r["n"]) ** 2, float(r["time_mean_s"]) * 1000) for r in everything)
        ax.plot([p[0] for p in pts], [p[1] for p in pts], "-o", color="#2563eb")
        ax.set_xlabel("n * n (number of cells)")
        ax.set_ylabel("Mean time (milliseconds)")
        ax.set_title("Constructive algorithms: time grows with n*n")
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        path = out_dir / "constructive_scaling.png"
        fig.savefig(path, dpi=150)
        plt.close(fig)
        paths.append(path)
    return paths


def main(argv=None) -> None:
    parser = argparse.ArgumentParser(description="Make the table and graphs from results.csv")
    parser.add_argument("--input", type=Path, default=HERE, help="folder containing results.csv (default: benchmarks)")
    parser.add_argument("--no-plots", action="store_true", help="only write the table")
    args = parser.parse_args(argv)

    rows = read_csv(args.input / "results.csv")
    estimates_path = args.input / "estimates.csv"
    estimates = read_csv(estimates_path) if estimates_path.exists() else []
    env_path = args.input / "environment.txt"
    environment = env_path.read_text(encoding="utf-8") if env_path.exists() else "(environment.txt not found)"

    table_path = args.input / "timing_table.md"
    table_path.write_text(build_table(rows, estimates, environment), encoding="utf-8")
    print(f"Wrote {table_path}")
    if args.no_plots:
        return
    try:
        for path in make_plots(rows, args.input):
            print(f"Wrote {path}")
    except ImportError:
        print("matplotlib is not installed, so no graphs were made.\n"
              "Install it with:  pip install matplotlib", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
