# Magic Square Lab

**Watch magic squares get built, step by step, then see why brute force can't compete.**

A Python desktop app (Tkinter, zero dependencies) that constructs magic squares of order 3 to 12, animates each algorithm with live pseudocode, verifies every row, column and diagonal, and races the constructive methods against two brute-force searches.

![Python](https://img.shields.io/badge/python-3.10%2B-blue) ![GUI](https://img.shields.io/badge/GUI-Tkinter-informational) ![Tests](https://img.shields.io/badge/tests-unittest-brightgreen) ![License](https://img.shields.io/badge/license-MIT-green)

<!-- Add a screenshot or GIF here: ![Demo](docs/demo.gif) -->

## Why this exists

A magic square is an n x n grid of 1..n² where every row, column and both diagonals add up to the same number, M(n) = n(n²+1)/2. Three different constructions cover every order, and each one is a nice little algorithm. This project makes them visible and measures them against the obvious brute-force approach.

## Features

- **Three constructive algorithms, picked automatically from n**, all O(n²)
  - Odd: Siamese method (de la Loubère)
  - Doubly even (4, 8, 12): diagonal / complement method
  - Singly even (6, 10): Strachey's method
- **Step-by-step simulation**: Start, Pause/Resume, Step, Reset, speed slider. The current cell is highlighted, and swaps highlight the partner cell too.
- **Algorithm panel**: pseudocode with the current line highlighted, "Step i / total", and a plain-English description of each event.
- **Independent validator**: shows M(n), every row/column/diagonal sum, and a VALID / NOT valid verdict.
- **Brute force, honestly reported**: naive permutation search and backtracking with pruning, each with a time limit, Stop button, and node/pruning counts. A search that hits a limit is never reported as a success.
- **Responsive UI**: searches run in a worker thread, so the window never freezes.
- **Input validation** with clear messages (empty, letters, decimals, negatives, 0, 1, 2, above 12).
- **Tests and benchmarks**: A full `unittest` suite, plus a benchmark script that writes a table and graphs.

## Quick start

```bash
git clone https://github.com/<your-username>/magic-square-lab.git
cd magic-square-lab
python main.py
```

Requires Python 3.10+ with Tkinter. On Windows keep "tcl/tk and IDLE" ticked in the installer; on Linux run `sudo apt install python3-tk`. Nothing else to install. On Windows you can also double-click `run_app.bat`, or `build_exe.bat` to build a standalone `MagicSquare.exe` with PyInstaller.

## Results

Constructive methods build any square in well under a millisecond for the supported sizes; brute force falls over almost immediately:

| Method | n = 3 | n = 4 | n = 5 to 8 |
|---|---|---|---|
| Constructive (Siamese / complement / Strachey) | 22 µs | 58 µs | 65 to 203 µs |
| Backtracking with pruning | 0.1 ms | 33 ms | not finished in 10 s |
| Naive permutations | 42 ms | not finished in 10 s | impossible |

At the measured speed, trying all 25! arrangements for n = 5 would take about 2.5 × 10¹¹ years. Pruning is what makes order 4 feasible: backtracking finds exactly 7,040 squares of order 4 (checked by an optional test), with no valid square lost.

![Time vs order](benchmarks/time_vs_order.png)

Full table: [`benchmarks/timing_table.md`](benchmarks/timing_table.md). These numbers were recorded on a single-core Linux machine with Python 3.12; re-run `python benchmarks/run_benchmarks.py` to measure your own hardware.

## Tests

```bash
python -m unittest discover -s tests -t . -v
```

GUI tests need a display and skip themselves otherwise. An optional slow test (`RUN_SLOW_TESTS=1`) verifies the 7,040 order-4 squares.

## Project layout

```
main.py            entry point
algorithms/        the three constructions, event system, validator, input check
brute_force/       naive and backtracking searches, threaded runner
gui/               Tkinter window, grid, panels, simulation controller
tests/             unit and GUI tests
benchmarks/        benchmark script, plots, results
docs/FULL_GUIDE.md original detailed guide, algorithm notes, troubleshooting
```

Design rule: the algorithms never touch the GUI and the GUI never computes a square. Algorithms emit a list of events (PLACE / COMPLEMENT / SWAP) and the GUI replays them one at a time.

## Known limitations

- Developed and tested on Linux; not yet verified by the author on Windows (fonts and spacing may differ).
- The window supports orders 3 to 12. The algorithms themselves work for larger orders (benchmarked to 100).
- Brute-force results appear instantly, without animation.

## AI usage

This project was built with AI assistance (Claude). Every phase, what was accepted, modified or rejected, and how it was tested is recorded in [`AI_LOG.md`](AI_LOG.md).

## License

MIT, see [LICENSE](LICENSE).
