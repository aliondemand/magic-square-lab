"""Runs a brute-force search in a WORKER THREAD so the GUI never freezes.

How the thread talks to the GUI
-------------------------------
Tkinter widgets may only be touched from the main (GUI) thread. So the worker
thread never touches the GUI. It only puts small messages into a thread-safe
queue.Queue. The GUI calls runner.poll() every ~100 ms (using root.after) and
reads the messages on the main thread.

Safety features
---------------
* Only ONE search can run at a time (start() refuses while a thread is alive).
* Every search has its own run id. Messages from an old (stale) search are
  thrown away by poll(), so they can never overwrite a newer result.
* Cancel uses a threading.Event that the search checks regularly.
* Any exception inside the worker is turned into an "error" message.
This file must NOT import tkinter.
"""

from __future__ import annotations

import queue
import threading
import time
from dataclasses import dataclass
from typing import Any, List, Optional

from .backtracking_search import backtracking_search
from .naive_search import DEFAULT_MAX_ARRANGEMENTS, naive_search
from .search_result import BACKTRACKING, NAIVE, STRATEGY_NAMES, SearchResult

DEFAULT_TIME_LIMIT_SECONDS = 30.0


class SearchBusyError(RuntimeError):
    """start() was called while another search is still running."""


@dataclass
class RunnerMessage:
    kind: str          # "progress", "finished" or "error"
    run_id: int
    payload: Any       # progress: (count, elapsed) | finished: SearchResult | error: text


def parse_strategy(value: str) -> str:
    """Turn a strategy name from the GUI into NAIVE or BACKTRACKING, or raise ValueError."""
    if isinstance(value, str):
        key = value.strip().lower()
        if key in STRATEGY_NAMES:
            return key
        for code, name in STRATEGY_NAMES.items():
            if key == name.lower():
                return code
    allowed = ", ".join(f"'{name}'" for name in STRATEGY_NAMES.values())
    raise ValueError(f"Unknown search strategy {value!r}. Choose one of: {allowed}.")


def run_search(strategy: str, n: int, cancel_event: Optional[threading.Event] = None,
               time_limit: Optional[float] = DEFAULT_TIME_LIMIT_SECONDS,
               max_count: Optional[int] = None, progress=None, **options) -> SearchResult:
    """Run one search synchronously (used by the runner thread, the benchmarks and the tests).

    max_count: safety limit. For naive search this is max arrangements (default 5,000,000);
               for backtracking it is max nodes (default: none, the time limit applies).
    """
    strategy = parse_strategy(strategy)
    if strategy == NAIVE:
        limit = DEFAULT_MAX_ARRANGEMENTS if max_count is None else max_count
        return naive_search(n, cancel_event, time_limit, limit, progress=progress, **options)
    return backtracking_search(n, cancel_event, time_limit, max_count, progress=progress, **options)


class SearchRunner:
    """Starts, cancels and reports one background search at a time."""

    def __init__(self) -> None:
        self._queue: "queue.Queue[RunnerMessage]" = queue.Queue()
        self._run_id = 0
        self._thread: Optional[threading.Thread] = None
        self._cancel_event: Optional[threading.Event] = None

    # --- state -------------------------------------------------------------
    @property
    def run_id(self) -> int:
        return self._run_id

    def is_running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def wait_until_idle(self, timeout: Optional[float] = None) -> bool:
        """Block until the worker thread has ended (for tests and shutdown). True if idle."""
        if self._thread is not None:
            self._thread.join(timeout)
        return not self.is_running()

    # --- control -----------------------------------------------------------
    def start(self, strategy: str, n: int, time_limit: Optional[float] = DEFAULT_TIME_LIMIT_SECONDS,
              max_count: Optional[int] = None) -> int:
        """Start a search in a new thread and return its run id."""
        strategy = parse_strategy(strategy)  # raises ValueError for an invalid choice
        if self.is_running():
            raise SearchBusyError("A search is still running. Stop it first.")
        self._run_id += 1
        run_id = self._run_id
        self._cancel_event = threading.Event()
        self._thread = threading.Thread(
            target=self._worker,
            args=(run_id, self._cancel_event, strategy, n, time_limit, max_count),
            name=f"search-{run_id}",
            daemon=True,  # a forgotten search can never keep the program alive
        )
        self._thread.start()
        return run_id

    def cancel(self) -> None:
        """Ask the running search to stop. It will send a 'finished' message with status CANCELLED."""
        if self._cancel_event is not None:
            self._cancel_event.set()

    def abandon(self) -> None:
        """Cancel AND ignore everything the current search still sends (used by Reset)."""
        self.cancel()
        self._run_id += 1  # old messages now carry a stale run id

    def poll(self) -> List[RunnerMessage]:
        """Return all waiting messages from the CURRENT run. Stale messages are discarded."""
        fresh: List[RunnerMessage] = []
        while True:
            try:
                message = self._queue.get_nowait()
            except queue.Empty:
                return fresh
            if message.run_id == self._run_id:
                fresh.append(message)

    # --- worker thread -----------------------------------------------------
    def _worker(self, run_id, cancel_event, strategy, n, time_limit, max_count) -> None:
        began = time.perf_counter()

        def progress(count: int) -> None:
            self._queue.put(RunnerMessage("progress", run_id, (count, time.perf_counter() - began)))

        try:
            result = run_search(strategy, n, cancel_event, time_limit, max_count, progress)
            self._queue.put(RunnerMessage("finished", run_id, result))
        except BaseException as exc:  # never let the thread die silently
            self._queue.put(RunnerMessage("error", run_id, f"{type(exc).__name__}: {exc}"))
