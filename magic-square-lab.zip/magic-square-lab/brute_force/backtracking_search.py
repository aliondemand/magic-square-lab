"""Backtracking search with pruning.

Idea
----
Fill the grid one cell at a time. For each cell try the numbers that are still
unused. As soon as it is IMPOSSIBLE for the current partial grid to grow into a
magic square, give up on it (prune) and go back one step (backtrack).

Pseudocode
----------
    place(position):
        if every cell is filled:  the square is magic -> success
        work out the window [low, high] of numbers that could still work here
        for every UNUSED number v in the window:
            write v in the cell, update the line sums, mark v as used
            count one node
            if place(position + 1) succeeds: return success
            undo everything (backtrack)
        return failure

The pruning rule ("value window")
---------------------------------
Every row, column and diagonal ("line") must end with the sum M(n).
Take a line that passes through the current cell. Let
    s = the sum of the cells already filled in that line
    k = the number of cells in that line that are still EMPTY after this cell.
Those k cells will hold k DIFFERENT numbers from 1..n*n, so together they add to
    at least  1 + 2 + ... + k            = k(k+1)/2          (smallest possible)
    at most   (N) + (N-1) + ... + (N-k+1) = k(2N-k+1)/2     (largest possible, N = n*n)
The new number v must satisfy
        s + v + (smallest possible rest) <= M      ->   v <= M - s - k(k+1)/2
        s + v + (largest possible rest)  >= M      ->   v >= M - s - k(2N-k+1)/2
Any v outside that window can NEVER lead to a magic square, so it is skipped.
Both inequalities are logically necessary, so no real solution is ever lost.
Special case k = 0: the cell is the LAST one of its line, so the window shrinks
to a single number v = M - s. (This "forced last cell" is the biggest saver.)
When a cell lies on several lines (row + column + maybe diagonals) the windows
are intersected. Numbers that are already used are skipped too ("used" table).

What is counted
---------------
    node    = one number written into one cell (one partial grid examined)
    pruned  = candidate numbers that were unused but skipped by the window rule

Complexity: worst case still exponential (there is no polynomial guarantee);
pruning only removes hopeless branches.
"""

from __future__ import annotations

import threading
import time
from typing import Callable, List, Optional, Tuple

from algorithms.validation import magic_constant, validate_square

from .search_result import (BACKTRACKING, CANCELLED, COUNT_LIMIT, ERROR, EXHAUSTED, FOUND,
                            TIME_LIMIT, SearchResult)

# Shown in the GUI's algorithm panel.
PSEUDOCODE = [
    "1. place(position): fill the grid one cell at a time.",
    "2. If every cell is filled: the square is magic -> STOP (found).",
    "3. For each line (row, column, diagonal) through this cell, work out",
    "       the smallest and largest value that can still reach M(n).",
    "4. For every UNUSED number v inside that window:",
    "5.     write v, update the line sums, count one node",
    "6.     recurse: place(position + 1)",
    "7.     undo the write (backtrack) if it did not work out",
    "8. Stop when found, cancelled, or a limit is reached.",
]

CHECK_EVERY = 1024  # nodes between looks at the clock / cancel flag

CELL_ORDERS = ("row_major", "diagonals_first")
VALUE_ORDERS = ("ascending", "descending")
DEFAULT_CELL_ORDER = "row_major"
DEFAULT_VALUE_ORDER = "ascending"


class _Stop(Exception):
    """Internal: unwinds the recursion when the search must stop early."""

    def __init__(self, status: str):
        super().__init__(status)
        self.status = status


def _cell_order(n: int, name: str) -> List[int]:
    """Return the order in which cells are filled (cell index = row * n + column)."""
    if name == "row_major":
        return list(range(n * n))
    if name == "diagonals_first":
        first = [i * n + i for i in range(n)]
        first += [i * n + (n - 1 - i) for i in range(n) if i * n + (n - 1 - i) not in first]
        return first + [c for c in range(n * n) if c not in first]
    raise ValueError(f"unknown cell order {name!r}")


def _build_plan(n: int, order: List[int]):
    """For each position in the fill order, list (line id, empty cells left in that line).

    Line ids: rows 0..n-1, columns n..2n-1, main diagonal 2n, secondary diagonal 2n+1.
    """
    members = [[] for _ in range(2 * n + 2)]
    for r in range(n):
        for c in range(n):
            cell = r * n + c
            members[r].append(cell)
            members[n + c].append(cell)
            if r == c:
                members[2 * n].append(cell)
            if r + c == n - 1:
                members[2 * n + 1].append(cell)
    where = {cell: pos for pos, cell in enumerate(order)}
    plan = []
    for pos, cell in enumerate(order):
        r, c = divmod(cell, n)
        line_ids = [r, n + c]
        if r == c:
            line_ids.append(2 * n)
        if r + c == n - 1:
            line_ids.append(2 * n + 1)
        entries: List[Tuple[int, int]] = []
        for lid in line_ids:
            empty_after = sum(1 for other in members[lid] if where[other] > pos)
            entries.append((lid, empty_after))
        plan.append((cell, entries))
    return plan


def backtracking_search(
    n: int,
    cancel_event: Optional[threading.Event] = None,
    time_limit: Optional[float] = None,
    max_nodes: Optional[int] = None,
    collect_all: bool = False,
    progress: Optional[Callable[[int], None]] = None,
    cell_order: str = DEFAULT_CELL_ORDER,
    value_order: str = DEFAULT_VALUE_ORDER,
) -> SearchResult:
    """Run the backtracking search. Look at result.status to see how it ended.

    time_limit   seconds, or None for no limit
    max_nodes    stop after this many nodes, or None
    collect_all  do not stop at the first square: count/collect every magic square
    progress     called now and then with the number of nodes so far
    """
    start = time.perf_counter()
    nodes = 0
    pruned = 0
    solutions: List[List[List[int]]] = []
    status = EXHAUSTED
    try:
        if n < 1:
            raise ValueError("order must be at least 1")
        if value_order not in VALUE_ORDERS:
            raise ValueError(f"unknown value order {value_order!r}")
        total = n * n
        target = magic_constant(n)
        plan = _build_plan(n, _cell_order(n, cell_order))
        line_sums = [0] * (2 * n + 2)
        used = [False] * (total + 1)
        grid = [0] * total
        smallest_rest = [k * (k + 1) // 2 for k in range(n + 1)]
        largest_rest = [k * (2 * total - k + 1) // 2 for k in range(n + 1)]
        ascending = value_order == "ascending"

        def place(pos: int) -> bool:
            """Try to fill position pos and everything after it. True = stop (found, single mode)."""
            nonlocal nodes, pruned
            if pos == total:
                solutions.append([grid[r * n:(r + 1) * n] for r in range(n)])
                return not collect_all

            cell, entries = plan[pos]
            low, high = 1, total
            for line, empty_after in entries:  # the "value window" pruning rule
                s = line_sums[line]
                lo = target - s - largest_rest[empty_after]
                hi = target - s - smallest_rest[empty_after]
                if lo > low:
                    low = lo
                if hi < high:
                    high = hi

            candidates = range(low, high + 1) if ascending else range(high, low - 1, -1)
            tried = 0
            for v in candidates:
                if used[v]:
                    continue
                if max_nodes is not None and nodes >= max_nodes:
                    raise _Stop(COUNT_LIMIT)
                tried += 1
                nodes += 1
                if nodes % CHECK_EVERY == 0:
                    if cancel_event is not None and cancel_event.is_set():
                        raise _Stop(CANCELLED)
                    if time_limit is not None and time.perf_counter() - start >= time_limit:
                        raise _Stop(TIME_LIMIT)
                    if progress is not None:
                        progress(nodes)
                # write v
                used[v] = True
                grid[cell] = v
                for line, _ in entries:
                    line_sums[line] += v
                done = place(pos + 1)
                # undo (backtrack)
                for line, _ in entries:
                    line_sums[line] -= v
                grid[cell] = 0
                used[v] = False
                if done:
                    return True
            pruned += (total - pos) - tried  # unused numbers that the window ruled out
            return False

        try:
            place(0)
        except _Stop as stop:
            status = stop.status
        if status == EXHAUSTED and solutions and not collect_all:
            status = FOUND
    except Exception as exc:  # report, never crash the caller
        elapsed = time.perf_counter() - start
        return SearchResult(BACKTRACKING, n, ERROR, nodes, elapsed, f"Search failed: {exc}", unit="nodes")
    elapsed = time.perf_counter() - start

    result = SearchResult(BACKTRACKING, n, status, nodes, elapsed, "", unit="nodes",
                          pruned=pruned, solution_count=len(solutions))
    if solutions:
        result.square = solutions[0]
        result.validation = validate_square(result.square)  # independent final check
        if collect_all:
            result.all_squares = solutions
        if not result.validation.is_valid:
            result.status = ERROR
    result.message = _message(result, time_limit, max_nodes)
    return result


def _message(r: SearchResult, time_limit, max_nodes) -> str:
    base = (f"Backtracking, order {r.n}: examined {r.examined:,} nodes "
            f"({r.pruned:,} candidates pruned) in {r.elapsed_seconds:.3f} s. ")
    if r.status == FOUND:
        return base + "A valid magic square was found."
    if r.status == EXHAUSTED:
        if r.solution_count:
            return base + f"Search finished: {r.solution_count:,} magic squares exist."
        return base + "Search finished: the whole search tree was explored and no magic square exists."
    if r.status == CANCELLED:
        return base + "Cancelled by the user. No result."
    if r.status == TIME_LIMIT:
        return base + f"Time limit of {time_limit} s reached. The search did NOT finish and found no square."
    if r.status == COUNT_LIMIT:
        return base + f"Safety limit of {max_nodes:,} nodes reached. The search did NOT finish and found no square."
    return base + "An internal error occurred."
