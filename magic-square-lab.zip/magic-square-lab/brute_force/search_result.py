"""The result record shared by both brute-force searches."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from algorithms.validation import ValidationResult

# --- Final status values ---------------------------------------------------
FOUND = "FOUND"              # a valid magic square was found
EXHAUSTED = "EXHAUSTED"      # the whole search space was explored (finished honestly)
CANCELLED = "CANCELLED"      # the user pressed Stop
TIME_LIMIT = "TIME_LIMIT"    # the time limit was reached BEFORE the search finished
COUNT_LIMIT = "COUNT_LIMIT"  # the safety limit on arrangements/nodes was reached
ERROR = "ERROR"              # something unexpected went wrong

NAIVE = "naive"
BACKTRACKING = "backtracking"
STRATEGY_NAMES = {
    NAIVE: "Naive permutation search",
    BACKTRACKING: "Backtracking with pruning",
}


@dataclass
class SearchResult:
    strategy: str                       # NAIVE or BACKTRACKING
    n: int
    status: str                         # one of the status values above
    examined: int                       # arrangements (naive) or nodes (backtracking)
    elapsed_seconds: float              # measured with time.perf_counter()
    message: str                        # plain-English summary for the GUI
    unit: str = "arrangements"          # "arrangements" or "nodes"
    square: Optional[List[List[int]]] = None
    validation: Optional[ValidationResult] = None
    pruned: int = 0                     # candidate values skipped by pruning (backtracking)
    solution_count: int = 0
    all_squares: List[List[List[int]]] = field(default_factory=list)  # only when collect_all=True

    @property
    def finished_honestly(self) -> bool:
        """True only if the search ended because it found something or ran out of options."""
        return self.status in (FOUND, EXHAUSTED)
