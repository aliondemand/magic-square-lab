"""Naive brute-force search: try permutations of 1 .. n*n one after another.

Pseudocode
----------
    1. For every permutation p of the numbers 1 ... n*n:
    2.     count the arrangement
    3.     lay p out row by row as an n x n grid
    4.     if every row, column and both diagonals sum to M(n): STOP, success
    5.     if the user pressed Stop / the time limit passed / the safety
           limit was reached: STOP, report that honestly
    6. If every permutation was tried, report that none was magic.

Why this is only practical for n = 3
------------------------------------
The number of arrangements is (n*n)!
    n = 3:  9!  = 362,880              (about a second in Python)
    n = 4: 16!  = 20,922,789,888,000   (millions of years at Python speed)
So for n >= 4 the search will normally stop at a LIMIT, never at an answer.
That is why a safety limit on the number of arrangements always exists.
"""

from __future__ import annotations

import math
import threading
import time
from itertools import permutations
from typing import Callable, Optional

from algorithms.validation import magic_constant, validate_square

from .search_result import (CANCELLED, COUNT_LIMIT, ERROR, EXHAUSTED, FOUND, NAIVE,
                            TIME_LIMIT, SearchResult)

# Shown in the GUI's algorithm panel.
PSEUDOCODE = [
    "1. For every permutation p of 1 ... n*n:",
    "2.     count one more arrangement",
    "3.     lay p out row by row as an n x n grid",
    "4.     if every row, column and both diagonals sum to M(n): STOP (found)",
    "5.     if Stop was pressed, the time limit or the safety limit is",
    "          reached: STOP and report that honestly",
    "6. If every permutation was tried: report that none is magic.",
]

# Safety limit: at most this many arrangements are examined unless the caller
# chooses another limit. (9! = 362,880 for order 3 is far below it.)
DEFAULT_MAX_ARRANGEMENTS = 5_000_000

CHECK_EVERY = 4096  # look at the clock / cancel flag this often (it is cheap, not free)


def search_space_size(n: int) -> int:
    """Number of arrangements a naive search must consider in the worst case: (n*n)!"""
    return math.factorial(n * n)


def naive_warning(n: int) -> Optional[str]:
    """Return a warning text for orders where naive search is impractical, else None."""
    if n <= 3:
        return None
    return (f"Naive search for order {n} has (n*n)! = {n * n}! = {search_space_size(n):,} possible "
            f"arrangements. That is impossible to finish. The search will stop at the safety limit "
            f"or the time limit and will NOT find a square. Use backtracking instead.")


def _is_magic(p, n: int, target: int) -> bool:
    """Fast magic check on a flat tuple (row-major). Used only inside the search loop.

    The final answer is ALSO checked by the independent validator.
    """
    for start in range(0, n * n, n):
        if sum(p[start:start + n]) != target:
            return False
    for c in range(n):
        if sum(p[c::n]) != target:
            return False
    if sum(p[0::n + 1]) != target:
        return False
    return sum(p[n - 1:n * n - 1:n - 1]) == target


def naive_search(
    n: int,
    cancel_event: Optional[threading.Event] = None,
    time_limit: Optional[float] = None,
    max_arrangements: Optional[int] = DEFAULT_MAX_ARRANGEMENTS,
    collect_all: bool = False,
    progress: Optional[Callable[[int], None]] = None,
) -> SearchResult:
    """Run the naive search. Never raises for a normal stop; look at result.status.

    cancel_event      set() it from another thread to stop the search
    time_limit        seconds, or None for no time limit
    max_arrangements  safety limit on arrangements examined, or None
    collect_all       keep going after the first success and collect every magic square
    progress          called now and then with the number of arrangements examined so far
    """
    start = time.perf_counter()
    examined = 0
    solutions = []
    status = EXHAUSTED
    try:
        if n < 1:
            raise ValueError("order must be at least 1")
        target = magic_constant(n)
        if n == 1:
            examined, solutions = 1, [[[1]]]
        else:
            for perm in permutations(range(1, n * n + 1)):
                examined += 1
                if _is_magic(perm, n, target):
                    solutions.append([list(perm[r * n:(r + 1) * n]) for r in range(n)])
                    if not collect_all:
                        break
                if max_arrangements is not None and examined >= max_arrangements:
                    status = COUNT_LIMIT
                    break
                if examined % CHECK_EVERY == 0:
                    if cancel_event is not None and cancel_event.is_set():
                        status = CANCELLED
                        break
                    if time_limit is not None and time.perf_counter() - start >= time_limit:
                        status = TIME_LIMIT
                        break
                    if progress is not None:
                        progress(examined)
        if solutions and status == EXHAUSTED:
            status = FOUND if not collect_all else EXHAUSTED
    except Exception as exc:  # report, never crash the caller
        elapsed = time.perf_counter() - start
        return SearchResult(NAIVE, n, ERROR, examined, elapsed, f"Search failed: {exc}")
    elapsed = time.perf_counter() - start

    result = SearchResult(NAIVE, n, status, examined, elapsed, "", unit="arrangements",
                          solution_count=len(solutions))
    if solutions:
        result.square = solutions[0]
        result.validation = validate_square(result.square)  # independent final check
        if collect_all:
            result.all_squares = solutions
        if not result.validation.is_valid:
            result.status = ERROR
    result.message = _message(result, time_limit, max_arrangements)
    return result


def _message(r: SearchResult, time_limit, max_arrangements) -> str:
    base = f"Naive search, order {r.n}: examined {r.examined:,} arrangements in {r.elapsed_seconds:.3f} s. "
    if r.status == FOUND:
        return base + "A valid magic square was found."
    if r.status == EXHAUSTED:
        if r.solution_count:
            return base + f"Search finished: {r.solution_count} magic squares exist."
        return base + "Search finished: every arrangement was tried and none is a magic square."
    if r.status == CANCELLED:
        return base + "Cancelled by the user. No result."
    if r.status == TIME_LIMIT:
        return base + f"Time limit of {time_limit} s reached. The search did NOT finish and found no square."
    if r.status == COUNT_LIMIT:
        return (base + f"Safety limit of {max_arrangements:,} arrangements reached. The search did NOT "
                f"finish and found no square.")
    return base + "An internal error occurred."
