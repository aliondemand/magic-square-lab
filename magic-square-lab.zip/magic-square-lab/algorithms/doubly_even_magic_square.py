"""Doubly-even magic squares (n = 4, 8, 12, ...): diagonal / complement method.

Pseudocode
----------
    1. Fill the grid with 1 ... n*n in reading order
       (left to right, top to bottom).
    2. Cut the grid into 4 x 4 blocks.
    3. In every block, mark the cells on its two diagonals.
    4. Replace the number k in every marked cell by n*n + 1 - k.
    5. Cells that are not marked keep their number. Done.

Why it works (short version): in every row of a 4 x 4 block exactly two
cells are marked. A marked cell and an unmarked cell in the same block
column pair up so that the sums balance out to the magic constant.
The validator proves it for every order we test.

Complexity: n*n placements + about n*n/2 complements = O(n^2).
"""

from __future__ import annotations

from typing import List

from .simulation_events import COMPLEMENT, PLACE, Event, replay_events

ALGORITHM_NAME = "Diagonal / complement method"

PSEUDOCODE = [
    "1. Fill the grid with 1 ... n*n in reading order.",
    "2. Cut the grid into 4 x 4 blocks.",
    "3. In every block, mark the cells on its two diagonals.",
    "4. Replace each marked number k by n*n + 1 - k.",
    "5. Unmarked cells keep their number. Done.",
]

LINE_FILL = 0
LINE_COMPLEMENT = 3


def is_marked(row: int, col: int) -> bool:
    """True if (row, col) lies on a diagonal of its own 4 x 4 block."""
    r, c = row % 4, col % 4
    return r == c or r + c == 3


def doubly_even_magic_square_events(n: int) -> List[Event]:
    """Return the events: n*n PLACE events, then one COMPLEMENT per marked cell."""
    if n < 4 or n % 4 != 0:
        raise ValueError(f"the diagonal/complement method needs n divisible by 4, got {n}")

    events: List[Event] = []
    total = n * n

    # Phase 1: reading-order fill.
    for r in range(n):
        for c in range(n):
            number = r * n + c + 1
            events.append(Event(
                kind=PLACE,
                cells=((r, c),),
                value=number,
                old_value=None,
                message=f"Fill in reading order: write {number} in row {r + 1}, column {c + 1}.",
                pseudo_line=LINE_FILL,
                phase="Fill 1 .. n*n in reading order",
            ))

    # Phase 2: complement the diagonal cells of every 4 x 4 block.
    for r in range(n):
        for c in range(n):
            if is_marked(r, c):
                old = r * n + c + 1
                new = total + 1 - old
                events.append(Event(
                    kind=COMPLEMENT,
                    cells=((r, c),),
                    value=new,
                    old_value=old,
                    message=(f"Cell (row {r + 1}, column {c + 1}) is on a block diagonal: "
                             f"replace {old} by {total} + 1 - {old} = {new}."),
                    pseudo_line=LINE_COMPLEMENT,
                    phase="Complement the block diagonals",
                ))
    return events


def doubly_even_magic_square(n: int) -> List[List[int]]:
    """Convenience function: return the finished doubly-even magic square."""
    return replay_events(n, doubly_even_magic_square_events(n))
