"""Chooses the right constructive algorithm for an order n and times it.

The timing covers ONLY the algorithm work (creating the events and building
the final square from them). It never includes animation delays.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import List

from . import doubly_even_magic_square as doubly_even
from . import odd_magic_square as odd
from . import singly_even_magic_square as singly_even
from .simulation_events import Event, replay_events

ODD = "Odd"
DOUBLY_EVEN = "Doubly even"
SINGLY_EVEN = "Singly even"

MIN_ORDER = 3
MAX_GUI_ORDER = 12  # the GUI limit; the algorithms themselves work for larger n


@dataclass
class ConstructionResult:
    n: int
    category: str
    algorithm_name: str
    pseudocode: List[str]
    events: List[Event]
    square: List[List[int]]
    elapsed_seconds: float


def classify_order(n: int) -> str:
    """Return ODD, DOUBLY_EVEN or SINGLY_EVEN for n >= 3."""
    if not isinstance(n, int) or isinstance(n, bool):
        raise ValueError("the order must be a whole number")
    if n < MIN_ORDER:
        raise ValueError(f"order {n} is not supported (the smallest supported order is {MIN_ORDER})")
    if n % 2 == 1:
        return ODD
    if n % 4 == 0:
        return DOUBLY_EVEN
    return SINGLY_EVEN


def algorithm_info(n: int):
    """Return (category, algorithm name, pseudocode lines) without running anything."""
    category = classify_order(n)
    if category == ODD:
        return category, odd.ALGORITHM_NAME, odd.PSEUDOCODE
    if category == DOUBLY_EVEN:
        return category, doubly_even.ALGORITHM_NAME, doubly_even.PSEUDOCODE
    return category, singly_even.ALGORITHM_NAME, singly_even.PSEUDOCODE


def construct(n: int) -> ConstructionResult:
    """Build a magic square of order n with the appropriate algorithm."""
    category, name, pseudocode = algorithm_info(n)

    start = time.perf_counter()
    if category == ODD:
        events = odd.odd_magic_square_events(n)
    elif category == DOUBLY_EVEN:
        events = doubly_even.doubly_even_magic_square_events(n)
    else:
        events = singly_even.singly_even_magic_square_events(n)
    square = replay_events(n, events)
    elapsed = time.perf_counter() - start

    return ConstructionResult(n, category, name, pseudocode, events, square, elapsed)
