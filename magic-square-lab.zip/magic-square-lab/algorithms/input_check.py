"""Checks the text the user types into the "Order n" box.

Two different kinds of problems are kept apart on purpose:

    InvalidInputError     the text is not a usable whole number at all
                          (empty, letters, decimals, zero, negatives)
    UnsupportedOrderError the text IS a whole number, but the program cannot
                          build a magic square of that order
                          (1, 2, or bigger than the GUI limit of 12)

Both carry a plain-English message that the GUI can show directly.
"""

from __future__ import annotations

import re
from typing import Union

from .dispatcher import MAX_GUI_ORDER, MIN_ORDER

_WHOLE_NUMBER = re.compile(r"[+-]?[0-9]+", re.ASCII)
_DECIMAL = re.compile(r"[+-]?([0-9]+\.[0-9]*|\.[0-9]+)", re.ASCII)

RANGE_HINT = f"Enter a whole number from {MIN_ORDER} to {MAX_GUI_ORDER}."


class InvalidInputError(ValueError):
    """The input is not a valid positive whole number."""
    kind = "invalid_input"


class UnsupportedOrderError(ValueError):
    """A valid whole number, but this order is not supported."""
    kind = "unsupported_order"


def parse_order(text: Union[str, int]) -> int:
    """Turn the user's text into an order n between 3 and 12, or raise an error."""
    if isinstance(text, bool) or not isinstance(text, (str, int)):
        raise InvalidInputError("The order must be typed as a whole number. " + RANGE_HINT)
    text = str(text).strip()

    if text == "":
        raise InvalidInputError("The order box is empty. " + RANGE_HINT)
    if _DECIMAL.fullmatch(text):
        raise InvalidInputError(f"'{text}' is a decimal number. The order must be a whole number. "
                                + RANGE_HINT)
    if not _WHOLE_NUMBER.fullmatch(text):
        raise InvalidInputError(f"'{text}' is not a number. Use digits only. " + RANGE_HINT)

    digits = text.lstrip("+-")
    negative = text.startswith("-")
    if len(digits.lstrip("0")) > 9:  # avoid converting absurdly long numbers
        if negative:
            raise InvalidInputError("The order cannot be negative. " + RANGE_HINT)
        raise UnsupportedOrderError(f"The order is too large. The largest supported order is {MAX_GUI_ORDER}.")

    n = int(text)
    if n < 0:
        raise InvalidInputError(f"The order cannot be negative ({n}). " + RANGE_HINT)
    if n == 0:
        raise InvalidInputError("The order cannot be zero. " + RANGE_HINT)
    if n == 1:
        raise UnsupportedOrderError("Order 1 is trivial: the only 'square' is the single number 1. "
                                    + RANGE_HINT)
    if n == 2:
        raise UnsupportedOrderError("No magic square of order 2 exists: the numbers 1 to 4 cannot be "
                                    "arranged so that all rows, columns and diagonals have the same sum. "
                                    + RANGE_HINT)
    if n > MAX_GUI_ORDER:
        raise UnsupportedOrderError(f"Order {n} is above the supported limit of {MAX_GUI_ORDER}. "
                                    + RANGE_HINT)
    return n
