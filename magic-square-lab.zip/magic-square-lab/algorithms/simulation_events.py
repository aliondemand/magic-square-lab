"""Simulation events.

Every constructive algorithm does NOT draw anything. Instead it writes down
what it does as a list of small "events". The GUI (written later) plays the
events one by one, so the user can watch the algorithm work.

Three kinds of events exist:

    PLACE       write a number into one empty cell
    COMPLEMENT  replace the number k in one cell by (n*n + 1 - k)
    SWAP        exchange the numbers stored in two cells

An empty cell is stored as the number 0.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Sequence, Tuple

PLACE = "PLACE"
COMPLEMENT = "COMPLEMENT"
SWAP = "SWAP"

Cell = Tuple[int, int]  # (row, column), counting from 0


@dataclass(frozen=True)
class Event:
    """One meaningful step of an algorithm.

    kind        PLACE, COMPLEMENT or SWAP
    cells       the cell(s) involved. PLACE/COMPLEMENT: one cell. SWAP: two cells.
    value       PLACE/COMPLEMENT: the NEW number in the cell.
                SWAP: the number that was in cells[0] before the swap.
    old_value   COMPLEMENT: the number that was there before.
                SWAP: the number that was in cells[1] before the swap.
                PLACE: None (the cell was empty).
    message     a plain-English sentence describing the step.
    pseudo_line the index (starting at 0) of the pseudocode line to highlight.
    phase       a short label for the part of the algorithm, e.g. "Swap columns".
    """

    kind: str
    cells: Tuple[Cell, ...]
    value: Optional[int]
    old_value: Optional[int]
    message: str
    pseudo_line: int
    phase: str


def empty_grid(n: int) -> List[List[int]]:
    """Return an n x n grid where every cell is 0 (meaning "empty")."""
    return [[0] * n for _ in range(n)]


def apply_event(grid: List[List[int]], event: Event) -> None:
    """Apply ONE event to the grid (the grid is changed in place).

    The function is strict on purpose. If an event does not match what is
    really in the grid (for example a PLACE onto a filled cell) it raises
    ValueError. This proves that the events tell the truth about the
    construction.
    """
    if event.kind == PLACE:
        (r, c), = event.cells
        if grid[r][c] != 0:
            raise ValueError(f"PLACE onto a filled cell {(r, c)}")
        grid[r][c] = event.value
    elif event.kind == COMPLEMENT:
        (r, c), = event.cells
        if grid[r][c] != event.old_value:
            raise ValueError(f"COMPLEMENT: cell {(r, c)} does not hold {event.old_value}")
        grid[r][c] = event.value
    elif event.kind == SWAP:
        (r1, c1), (r2, c2) = event.cells
        if grid[r1][c1] != event.value or grid[r2][c2] != event.old_value:
            raise ValueError(f"SWAP of {event.cells}: cells do not hold the expected numbers")
        grid[r1][c1], grid[r2][c2] = grid[r2][c2], grid[r1][c1]
    else:
        raise ValueError(f"unknown event kind {event.kind!r}")


def replay_events(n: int, events: Sequence[Event]) -> List[List[int]]:
    """Start from an empty n x n grid and apply every event in order."""
    grid = empty_grid(n)
    for event in events:
        apply_event(grid, event)
    return grid
