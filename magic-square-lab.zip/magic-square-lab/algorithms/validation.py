"""Independent magic square validator.

This file does NOT import any construction algorithm. It only looks at a
finished grid and answers: "Is this a real magic square?"
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, List


def magic_constant(n: int) -> int:
    """Magic constant M(n) = n * (n^2 + 1) / 2.

    n * (n*n + 1) is always even, so integer division is exact.
    """
    return n * (n * n + 1) // 2


@dataclass
class ValidationResult:
    order: int
    magic_constant: int
    is_valid: bool
    row_sums: List[int] = field(default_factory=list)
    column_sums: List[int] = field(default_factory=list)
    main_diagonal_sum: int | None = None
    secondary_diagonal_sum: int | None = None
    errors: List[str] = field(default_factory=list)

    def summary(self) -> str:
        if self.is_valid:
            return f"Valid magic square of order {self.order} (magic constant {self.magic_constant})."
        return "NOT a magic square: " + "; ".join(self.errors)


def _is_plain_int(value: Any) -> bool:
    # bool is a subclass of int in Python, but True/False are not valid entries.
    return isinstance(value, int) and not isinstance(value, bool)


def validate_square(square: Any) -> ValidationResult:
    """Check every rule of a magic square and return a full report."""
    errors: List[str] = []

    # --- 1. Shape: exactly n rows and n columns -----------------------------
    if not isinstance(square, (list, tuple)) or len(square) == 0:
        return ValidationResult(0, 0, False, errors=["the grid is empty or is not a list of rows"])
    n = len(square)
    if any(not isinstance(row, (list, tuple)) for row in square):
        return ValidationResult(n, magic_constant(n), False, errors=["some rows are not lists"])
    bad_rows = [i + 1 for i, row in enumerate(square) if len(row) != n]
    if bad_rows:
        return ValidationResult(
            n, magic_constant(n), False,
            errors=[f"grid is not {n} x {n}: row(s) {bad_rows} have the wrong length"],
        )

    target = magic_constant(n)
    values = [v for row in square for v in row]

    # --- 2. Values: 1..n^2 exactly once, nothing missing --------------------
    if any(not _is_plain_int(v) for v in values):
        return ValidationResult(n, target, False, errors=["some cells do not contain whole numbers"])
    expected = set(range(1, n * n + 1))
    seen = set()
    duplicates = sorted({v for v in values if v in seen or seen.add(v)})
    missing = sorted(expected - set(values))
    out_of_range = sorted({v for v in values if v not in expected})
    if duplicates:
        errors.append(f"duplicate values: {duplicates}")
    if missing:
        errors.append(f"missing values: {missing}")
    if out_of_range:
        errors.append(f"values outside 1..{n * n}: {out_of_range}")

    # --- 3. Sums -------------------------------------------------------------
    row_sums = [sum(row) for row in square]
    column_sums = [sum(square[r][c] for r in range(n)) for c in range(n)]
    main_diag = sum(square[i][i] for i in range(n))
    second_diag = sum(square[i][n - 1 - i] for i in range(n))

    for i, s in enumerate(row_sums):
        if s != target:
            errors.append(f"row {i + 1} sums to {s}, expected {target}")
    for i, s in enumerate(column_sums):
        if s != target:
            errors.append(f"column {i + 1} sums to {s}, expected {target}")
    if main_diag != target:
        errors.append(f"main diagonal sums to {main_diag}, expected {target}")
    if second_diag != target:
        errors.append(f"secondary diagonal sums to {second_diag}, expected {target}")

    return ValidationResult(
        order=n,
        magic_constant=target,
        is_valid=not errors,
        row_sums=row_sums,
        column_sums=column_sums,
        main_diagonal_sum=main_diag,
        secondary_diagonal_sum=second_diag,
        errors=errors,
    )
