"""Singly-even magic squares (n = 6, 10, 14, ...): Strachey's method.

Idea
----
Let m = n / 2 (an odd number) and k = (m - 1) / 2.
Cut the n x n grid into four m x m quarters. Fill each quarter with an odd
magic square made by the Siamese method, then swap a few columns between
quarters to repair the row and diagonal sums.

        +---------+---------+
        |    A    |    C    |        A = Siamese square
        | top-left| top-right|       B = A + m*m   (bottom-right)
        +---------+---------+        C = A + 2*m*m (top-right)
        |    D    |    B    |        D = A + 3*m*m (bottom-left)
        |bot-left |bot-right|
        +---------+---------+

Pseudocode
----------
    1. m = n / 2 and k = (m - 1) / 2.
    2. Build an odd magic square A of order m (Siamese method).
    3. Fill the four quarters: top-left = A, bottom-right = A + m*m,
       top-right = A + 2*m*m, bottom-left = A + 3*m*m.
    4. For every row r of the top half (0 .. m-1):
           swap the leftmost k cells of row r with the cells directly below
           (in the bottom half). In the MIDDLE row (r = k) start one column
           further right (columns 1 .. k instead of 0 .. k-1).
    5. For every row r of the top half:
           swap the rightmost k - 1 cells of row r with the cells below.
    6. Done.

Complexity: n*n placements + O(n^2) swaps = O(n^2).
"""

from __future__ import annotations

from typing import List

from .odd_magic_square import odd_magic_square_events
from .simulation_events import SWAP, Event, apply_event, empty_grid

ALGORITHM_NAME = "Strachey's method"

PSEUDOCODE = [
    "1. m = n / 2 and k = (m - 1) / 2.",
    "2. Build an odd magic square A of order m (Siamese method).",
    "3. Fill the quarters: top-left = A, bottom-right = A + m*m,",
    "      top-right = A + 2*m*m, bottom-left = A + 3*m*m.",
    "4. Swap the leftmost k columns of the top-left and bottom-left",
    "      quarters (in the middle row, use columns 1 .. k instead).",
    "5. Swap the rightmost k - 1 columns of the top-right and",
    "      bottom-right quarters.",
    "6. Done.",
]

LINE_BUILD = 2   # highlighted while quarters are being filled
LINE_LEFT = 4    # highlighted during the left swaps
LINE_RIGHT = 6   # highlighted during the right swaps


def singly_even_magic_square_events(n: int) -> List[Event]:
    """Return the events: four Siamese quarters, then the SWAP events."""
    if n < 6 or n % 4 != 2:
        raise ValueError(f"Strachey's method needs n = 6, 10, 14, ... (n mod 4 = 2), got {n}")

    m = n // 2
    k = (m - 1) // 2
    events: List[Event] = []

    quarters = [
        ("top-left", 0, 0, 0),
        ("bottom-right", m, m, m * m),
        ("top-right", 0, m, 2 * m * m),
        ("bottom-left", m, 0, 3 * m * m),
    ]
    for name, row0, col0, add in quarters:
        events.extend(odd_magic_square_events(
            m,
            row_offset=row0,
            col_offset=col0,
            value_offset=add,
            pseudo_lines=(LINE_BUILD, LINE_BUILD, LINE_BUILD),
            phase=f"Siamese method for the {name} quarter",
            label=f"[{name} quarter, +{add}] ",
        ))

    # Replay the placements so we know the exact numbers sitting in each cell.
    work = empty_grid(n)
    for event in events:
        apply_event(work, event)

    def add_swap(r1: int, c1: int, r2: int, c2: int, line: int, phase: str) -> None:
        swap = Event(
            kind=SWAP,
            cells=((r1, c1), (r2, c2)),
            value=work[r1][c1],
            old_value=work[r2][c2],
            message=(f"Swap {work[r1][c1]} (row {r1 + 1}, column {c1 + 1}) with "
                     f"{work[r2][c2]} (row {r2 + 1}, column {c2 + 1})."),
            pseudo_line=line,
            phase=phase,
        )
        apply_event(work, swap)
        events.append(swap)

    # Step 4: left swaps (top-left <-> bottom-left).
    for r in range(m):
        columns = range(1, k + 1) if r == k else range(0, k)
        for c in columns:
            add_swap(r, c, r + m, c, LINE_LEFT, "Swap columns on the left side")

    # Step 5: right swaps (top-right <-> bottom-right), k - 1 columns.
    for r in range(m):
        for c in range(n - (k - 1), n):
            add_swap(r, c, r + m, c, LINE_RIGHT, "Swap columns on the right side")

    return events


def singly_even_magic_square(n: int) -> List[List[int]]:
    """Convenience function: return the finished singly-even magic square."""
    from .simulation_events import replay_events
    return replay_events(n, singly_even_magic_square_events(n))
