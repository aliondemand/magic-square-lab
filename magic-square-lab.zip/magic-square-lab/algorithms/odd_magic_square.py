"""Odd-order magic squares: the Siamese (de la Loubere) method.

Pseudocode
----------
    1. Create an empty n x n grid.
    2. Put 1 in the top row, middle column.
    3. For every next number k = 2 ... n*n:
    4.     Look at the cell one row UP and one column RIGHT of the last
           cell. If we fall off an edge, wrap around to the other side.
    5.     If that cell is already filled, ignore it. Go back to the last
           cell and move one row DOWN instead.
    6.     Write k in the chosen cell.
    7. Stop when n*n has been written.

Complexity: every number is placed once with O(1) work, so O(n^2) overall.
"""

from __future__ import annotations

from typing import List, Tuple

from .simulation_events import PLACE, Event, replay_events

ALGORITHM_NAME = "Siamese method (de la Loubere)"

PSEUDOCODE = [
    "1. Create an empty n x n grid.",
    "2. Put 1 in the top row, middle column.",
    "3. For each next number k = 2 ... n*n:",
    "4.     Move one row UP and one column RIGHT (wrap around the edges).",
    "5.     If that cell is filled, go back and move one row DOWN instead.",
    "6.     Write k in the chosen cell.",
    "7. Stop when n*n has been placed.",
]

# Indexes into PSEUDOCODE (counting from 0) used when highlighting.
LINE_FIRST = 1      # "Put 1 in the top row, middle column"
LINE_NORMAL = 3     # "Move up and right"
LINE_COLLISION = 4  # "Filled, so move down instead"


def odd_magic_square_events(
    n: int,
    row_offset: int = 0,
    col_offset: int = 0,
    value_offset: int = 0,
    pseudo_lines: Tuple[int, int, int] = (LINE_FIRST, LINE_NORMAL, LINE_COLLISION),
    phase: str = "Siamese method",
    label: str = "",
) -> List[Event]:
    """Return the list of PLACE events that build an odd magic square.

    The extra arguments let the singly-even algorithm reuse this function to
    build a quarter of a bigger grid:
        row_offset, col_offset  where the little square sits in the big grid
        value_offset            number added to every value (0 for a normal run)
        pseudo_lines            pseudocode lines to highlight (first, normal, collision)
        label                   text added to messages, e.g. "top-left quarter: "
    """
    if n < 1 or n % 2 == 0:
        raise ValueError(f"the Siamese method needs an odd order, got {n}")

    first_line, normal_line, collision_line = pseudo_lines
    local = [[0] * n for _ in range(n)]  # remembers which cells are filled
    events: List[Event] = []
    row, col = 0, n // 2  # start: top row, middle column

    for k in range(1, n * n + 1):
        if k == 1:
            line = first_line
            message = (f"{label}Place 1 in the top row, middle column "
                       f"(row 1, column {col + 1}).")
        else:
            up_row, right_col = row - 1, col + 1
            wrapped = []
            if up_row < 0:
                wrapped.append("top edge")
            if right_col >= n:
                wrapped.append("right edge")
            new_row, new_col = up_row % n, right_col % n
            wrap_text = f" (wrapped over the {' and '.join(wrapped)})" if wrapped else ""
            if local[new_row][new_col] != 0:
                # Target is taken: go DOWN one row from the previous cell.
                line = collision_line
                new_row, new_col = (row + 1) % n, col
                message = (f"{label}Number {k + value_offset}: up-right cell is already "
                           f"filled{wrap_text}, so move down from row {row + 1}, column "
                           f"{col + 1} to row {new_row + 1}, column {new_col + 1}.")
            else:
                line = normal_line
                message = (f"{label}Number {k + value_offset}: move up-right from row "
                           f"{row + 1}, column {col + 1} to row {new_row + 1}, column "
                           f"{new_col + 1}{wrap_text}.")
            row, col = new_row, new_col

        local[row][col] = k
        events.append(Event(
            kind=PLACE,
            cells=((row + row_offset, col + col_offset),),
            value=k + value_offset,
            old_value=None,
            message=message,
            pseudo_line=line,
            phase=phase,
        ))
    return events


def odd_magic_square(n: int) -> List[List[int]]:
    """Convenience function: return the finished odd magic square."""
    return replay_events(n, odd_magic_square_events(n))
